from app.embeddings.embedder import get_embedding
from app.vectorstore.faiss_store import search


def retrieve_chunks(question):

    query_embedding = get_embedding(question)

    results = search(query_embedding)

    return results