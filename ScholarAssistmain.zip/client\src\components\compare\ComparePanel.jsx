import { useState } from "react";

import api from "../../lib/api";
import { tryRecordHistory } from "../../lib/nodeApi";

function ComparePanel() {
  const [comparison, setComparison] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleCompare() {
    setLoading(true);
    setError("");

    try {
      const { data } = await api.post("/compare");
      setComparison(data.comparison);
      await tryRecordHistory("compare", "Compared indexed papers");
    } catch (err) {
      setError(err.response?.data?.detail || "Could not compare papers");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="border-b border-greyBlue p-4">
      <div className="mb-2 flex items-center justify-between gap-3">
        <h3 className="font-semibold text-primary dark:text-softBlue">
          Compare Papers
        </h3>
        <button
          onClick={handleCompare}
          disabled={loading}
          className="rounded-lg bg-primary px-3 py-2 text-sm text-white disabled:opacity-50"
        >
          {loading ? "Comparing..." : "Compare"}
        </button>
      </div>

      {error && (
        <p className="text-sm text-red-600">
          {error}
        </p>
      )}

      {comparison && (
        <div className="max-h-44 overflow-y-auto whitespace-pre-wrap rounded-lg border border-greyBlue bg-white/70 p-3 text-sm text-textPrimary dark:border-slate-700 dark:bg-slate-900 dark:text-gray-100">
          {comparison}
        </div>
      )}
    </div>
  );
}

export default ComparePanel;
