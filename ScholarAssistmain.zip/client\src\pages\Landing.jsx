import { Link } from "react-router-dom"
import { motion as Motion } from "framer-motion"
import { useAuth } from "../context/useAuth"
import TopNavbar from "../components/layout/TopNavbar"

function Landing() {
  const { authenticated } = useAuth()

  return (

    <div className="research-hero-bg relative min-h-screen overflow-x-hidden">

      {/* Patterned Background */}

      <div className="hero-grid-layer absolute inset-0 opacity-60 dark:opacity-15" />
      <div className="hero-dot-layer absolute inset-0 opacity-45 dark:opacity-30" />
      <div className="hero-diagonal-layer absolute inset-0 opacity-40 dark:opacity-20" />
      <div className="hero-contour-layer absolute inset-0 opacity-[0.08] dark:opacity-[0.09]" />

      {/* Glow Gradient Effects */}

      <div className="absolute left-[-200px] top-[-200px] h-[600px] w-[600px] bg-[#567CBD] opacity-20 blur-[200px] dark:opacity-30" />

      <div className="absolute bottom-[-200px] right-[-200px] h-[500px] w-[500px] bg-[#7096D1] opacity-20 blur-[200px] dark:opacity-30" />

      <div className="absolute left-1/2 top-1/3 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-[#BAD6EB] opacity-10 blur-[160px]" />



      <TopNavbar transparent />



      {/* Hero Section */}

      <section className="relative z-10 mt-14 flex flex-col items-center px-4 text-center sm:mt-24 sm:px-6 lg:mt-28">

        <Motion.h1
          initial={{ opacity:0, y:40 }}
          animate={{ opacity:1, y:0 }}
          transition={{ duration:0.8 }}
          className="max-w-4xl text-3xl font-bold leading-tight sm:text-5xl lg:text-6xl"
        >

          <span className="text-[#081F5C] drop-shadow-sm dark:text-white">
            Intelligent
          </span>{" "}

          <span className="bg-gradient-to-r from-[#334EAC] to-[#567CBD] bg-clip-text text-transparent dark:from-[#BAD6EB] dark:to-[#7096D1]">

            Research Assistant

          </span>

          <br />

          <span className="text-[#081F5C] drop-shadow-sm dark:text-white">
            for Academic Papers
          </span>

        </Motion.h1>



        <Motion.p
          initial={{ opacity:0 }}
          animate={{ opacity:1 }}
          transition={{ delay:0.3 }}
          className="mt-5 max-w-2xl text-base font-medium leading-7 text-[#1F335C] dark:text-[#C8D9E6] sm:mt-6 sm:text-lg sm:leading-8"
        >

          Upload papers, ask questions, generate citations,
          compare research, and extract insights instantly with AI.

        </Motion.p>



        {/* CTA Buttons */}

        <Motion.div
          initial={{ opacity:0 }}
          animate={{ opacity:1 }}
          transition={{ delay:0.5 }}
          className="mt-8 flex flex-wrap justify-center gap-4 sm:mt-10 sm:gap-6"
        >

          <Link to={authenticated ? "/workspace" : "/auth"}>

            <button className="rounded-xl bg-[#334EAC] px-6 py-3 text-base text-white shadow-xl shadow-[#334EAC]/30 transition hover:bg-[#567CBD] sm:px-8 sm:py-4 sm:text-lg">

              {authenticated ? "Open Workspace" : "Create Your Workspace"}

            </button>

          </Link>


        </Motion.div>

      </section>



      {/* Feature Cards */}

      <section className="relative z-10 mt-16 grid gap-4 px-4 sm:mt-24 sm:px-8 md:grid-cols-3 lg:px-16">

        <Motion.div
          whileHover={{ scale:1.05 }}
          className="rounded-xl border border-[#334EAC]/15 bg-white/50 p-5 backdrop-blur-lg dark:border-white/10 dark:bg-white/5 sm:p-8"
        >

          <h3 className="mb-3 text-xl font-semibold text-primary dark:text-white">
            AI Paper Summaries
          </h3>

          <p className="text-[#1F335C] dark:text-[#C8D9E6]">
            Instantly understand complex research papers using AI generated summaries.
          </p>

        </Motion.div>



        <Motion.div
          whileHover={{ scale:1.05 }}
          className="rounded-xl border border-[#334EAC]/15 bg-white/50 p-5 backdrop-blur-lg dark:border-white/10 dark:bg-white/5 sm:p-8"
        >

          <h3 className="mb-3 text-xl font-semibold text-primary dark:text-white">
            Semantic Search
          </h3>

          <p className="text-[#1F335C] dark:text-[#C8D9E6]">
            Search concepts across papers using intelligent embeddings.
          </p>

        </Motion.div>



        <Motion.div
          whileHover={{ scale:1.05 }}
          className="rounded-xl border border-[#334EAC]/15 bg-white/50 p-5 backdrop-blur-lg dark:border-white/10 dark:bg-white/5 sm:p-8"
        >

          <h3 className="mb-3 text-xl font-semibold text-primary dark:text-white">
            Smart Citations
          </h3>

          <p className="text-[#1F335C] dark:text-[#C8D9E6]">
            Generate APA, MLA, IEEE and BibTex citations instantly.
          </p>

        </Motion.div>

      </section>



      {/* Footer */}

      <footer className="relative z-10 mt-20 px-4 pb-10 text-center text-sm text-textSecondary dark:text-[#A9CBE0] sm:mt-32 sm:text-base">

        Copyright 2026 ScholarAssist - AI Research Workspace

      </footer>

    </div>

  )
}

export default Landing

