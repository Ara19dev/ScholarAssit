import { useState } from "react"
import { MessageSquare } from "lucide-react"

import { askPaper } from "../../lib/api"
import { tryRecordHistory } from "../../lib/nodeApi"
import StructuredOutput from "../common/StructuredOutput"

function FloatingChat({ paper }){

  const [open,setOpen] = useState(false)
  const [messages, setMessages] = useState([
    { role: "assistant", text: "Ask me anything about the selected paper." }
  ])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)

  async function sendMessage(){
    if(!paper || !input.trim() || loading) return

    const nextMessages = [...messages, { role: "user", text: input }]
    setMessages(nextMessages)
    setInput("")
    setLoading(true)

    try{
      const result = await askPaper(input, paper)
      await tryRecordHistory("qna", input, paper)
      setMessages([...nextMessages, { role: "assistant", text: result.answer }])
    }catch(err){
      setMessages([
        ...nextMessages,
        { role: "assistant", text: err.response?.data?.detail || "Could not answer from this paper." }
      ])
    }finally{
      setLoading(false)
    }
  }

  return(

    <div className="fixed bottom-4 right-4 z-40 sm:bottom-6 sm:right-6">

      {open && (

        <div className="flex h-[min(34rem,calc(100vh-7rem))] w-[calc(100vw-2rem)] max-w-96 flex-col rounded-xl border border-gray-200 bg-white shadow-xl dark:border-gray-700 dark:bg-[#0B1120]">

          <div className="border-b p-3 font-semibold dark:border-gray-700">
            AI Assistant
          </div>

          <div className="flex-1 space-y-3 overflow-y-auto p-3 text-sm">
            {messages.map((message,index)=>(
              <div
                key={index}
                className={`rounded-lg p-3 ${
                  message.role === "user"
                    ? "ml-auto bg-[#334EAC] text-white"
                    : "mr-auto bg-gray-100 text-textPrimary dark:bg-slate-800 dark:text-gray-100"
                }`}
              >
                {message.role === "assistant" ? (
                  <StructuredOutput text={message.text} compact />
                ) : (
                  message.text
                )}
              </div>
            ))}
          </div>

          <div className="flex gap-2 border-t p-3 dark:border-gray-700">
            <input
              value={input}
              onChange={(event)=>setInput(event.target.value)}
              onKeyDown={(event)=>{ if(event.key === "Enter") sendMessage() }}
              placeholder={paper ? "Ask about this paper..." : "Upload a PDF first"}
              disabled={!paper || loading}
              className="min-w-0 flex-1 rounded-lg border border-greyBlue bg-white px-3 py-2 text-textPrimary outline-none dark:bg-slate-900 dark:text-gray-100"
            />
            <button
              onClick={sendMessage}
              disabled={!paper || loading}
              className="rounded-lg bg-[#334EAC] px-3 py-2 text-white disabled:opacity-50"
            >
              Send
            </button>
          </div>

        </div>

      )}

      <button
        onClick={()=>setOpen(!open)}
        className="mt-3 rounded-full bg-[#334EAC] p-3 text-white shadow-lg"
      >
        <MessageSquare size={20}/>
      </button>

    </div>

  )

}

export default FloatingChat
