# Scholar Assist Installation Guide

This guide explains how to run Scholar Assist after receiving the project zip.

## Requirements

Install these first:

- Node.js 18 or newer
- Python 3.11 or newer
- VS Code
- MongoDB Atlas connection string
- Gemini API key

## 1. Unzip The Project

Unzip the folder anywhere, for example:

```text
E:\scholar_assist
```

Open that folder in VS Code.

## 2. Install Frontend Dependencies

```powershell
cd E:\scholar_assist\client
npm install
```

## 3. Install Node API Dependencies

```powershell
cd E:\scholar_assist\api-server
npm install
```

## 4. Install AI Service Dependencies

```powershell
cd E:\scholar_assist\ai-service
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
```

## 5. Create Environment Files

Create this file:

```text
api-server\.env
```

Add:

```text
PORT=5000
MONGO_URI=your-mongodb-atlas-uri
JWT_SECRET=replace-with-a-long-random-secret
CLIENT_ORIGIN=http://localhost:5173,http://127.0.0.1:5173,http://localhost:5175
```

Create this file:

```text
ai-service\.env
```

Add:

```text
GEMINI_API_KEY=your-gemini-api-key
```

Frontend env is optional. Only create `client\.env` if ports are different:

```text
VITE_API_BASE_URL=http://localhost:8000
VITE_NODE_API_BASE_URL=http://localhost:5000
```

## 6. Run The Project

Open three VS Code terminals.

Terminal 1, AI service:

```powershell
cd E:\scholar_assist\ai-service
.\.venv\Scripts\activate
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Terminal 2, Node API:

```powershell
cd E:\scholar_assist\api-server
node src/index.js
```

Terminal 3, frontend:

```powershell
cd E:\scholar_assist\client
npm run dev
```

Open the frontend URL shown by Vite, usually:

```text
http://localhost:5173
```

## Useful Test URLs

AI service:

```text
http://127.0.0.1:8000/
http://127.0.0.1:8000/docs
```

Node API:

```text
http://localhost:5000/health
```

## Notes

- Do not commit or share `.env` files publicly.
- The first AI service startup can be slow because the embedding model loads.
- Uploaded PDF files are saved in MongoDB GridFS through the Node API.
- Extracted text and FAISS runtime data are created locally by the AI service during development.
