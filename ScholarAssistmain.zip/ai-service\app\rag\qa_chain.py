from google import genai
from app.config import GEMINI_API_KEY, LLM_MODEL
from app.rag.errors import raise_friendly_ai_error

client = genai.Client(api_key=GEMINI_API_KEY)


def generate_answer(question, context):

    context_text = ""

    for c in context:
        context_text += f"(Page {c['page']}): {c['text']}\n\n"

    prompt = f"""
Answer the question using ONLY the context below.

Format:
Answer:
- Give the direct answer in 2-5 short bullets.

Evidence:
- Include the most relevant page citations like [Page X].

Do not use markdown tables, pipe characters, HTML, or hash headings.

Context:
{context_text}

Question:
{question}

"""

    try:
        response = client.models.generate_content(
            model=LLM_MODEL,
            contents=prompt
        )
    except Exception as error:
        raise_friendly_ai_error(error)

    return response.text

def generate_summary(context):

    context_text = ""

    for c in context:
        context_text += f"(Paper: {c['paper']} | Page {c['page']}): {c['text']}\n\n"

    prompt = f"""
You are an academic research assistant.

Summarize the research paper using the context below.

Provide the summary using exactly these headings.
Use short bullets under each heading.
Do not use markdown tables, pipe characters, HTML, or hash headings.

Problem:
Method:
Dataset:
Results:
Limitations:
Research Gap:

Context:
{context_text}
"""

    try:
        response = client.models.generate_content(
            model=LLM_MODEL,
            contents=prompt
        )
    except Exception as error:
        raise_friendly_ai_error(error)

    return response.text
