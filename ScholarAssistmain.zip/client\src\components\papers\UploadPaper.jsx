import { useDropzone } from "react-dropzone";
import { useState } from "react";
import { Upload } from "lucide-react";

import { ingestPaper } from "../../lib/api";
import { tryRecordHistory, trySavePaperRecord, tryUploadPaperPdf } from "../../lib/nodeApi";

function UploadPaper({ compact = false, onIndexed, setFile, setPaper }) {

  const [status, setStatus] = useState("");
  const [error, setError] = useState("");

  const { getRootProps, getInputProps } = useDropzone({
    accept: { "application/pdf": [] },
    multiple: false,
    onDrop: async (acceptedFiles) => {
      const selectedFile = acceptedFiles[0];

      if (!selectedFile) return;

      setFile(selectedFile);
      setError("");
      setStatus("Indexing PDF...");

      try {
        const result = await ingestPaper(selectedFile);
        onIndexed?.(result, selectedFile);
        await trySavePaperRecord({
          filename: result.paper,
          originalName: selectedFile.name,
          chunks: result.chunks,
          extractedText: result.extracted_text || "",
        });
        await tryUploadPaperPdf(result.paper, selectedFile);
        await tryRecordHistory("ingest", `Indexed ${selectedFile.name}`, result.paper);
        setStatus(`Indexed ${result.paper} (${result.chunks} chunks)`);
      } catch (err) {
        setPaper("");
        setError(
          err.response?.data?.detail
          || (err.request ? "Could not reach the AI indexing service. Check that FastAPI is running and restart it after backend changes." : "Could not index the PDF")
        );
        setStatus("");
      }
    }
  });

  if (compact) {
    return (
      <div>
        <button
          type="button"
          {...getRootProps()}
          className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-[#334EAC] px-4 py-2 font-semibold text-white hover:bg-[#567CBD] sm:w-auto"
        >
          <input {...getInputProps()} />
          <Upload size={18} />
          Upload Paper
        </button>

        {(status || error) && (
          <p className={`mt-2 text-xs ${error ? "text-red-600" : "text-primary dark:text-softBlue"}`}>
            {error || status}
          </p>
        )}
      </div>
    );
  }

  return (
    <div
      {...getRootProps()}
      className="cursor-pointer rounded-lg border-2 border-dashed border-greyBlue p-4 text-center hover:bg-bgSoft dark:hover:bg-slate-800 sm:p-8"
    >
      <input {...getInputProps()} />

      <p className="text-textSecondary">
        Drag & Drop PDF here or click to upload
      </p>

      {status && (
        <p className="mt-3 text-sm text-primary dark:text-softBlue">
          {status}
        </p>
      )}

      {error && (
        <p className="mt-3 text-sm text-red-600">
          {error}
        </p>
      )}

    </div>
  );
}

export default UploadPaper;
