import { useState } from "react";

import { changeCitationStyle } from "../../lib/api";

const styles = [
  { label: "ACS", value: "acs" },
  { label: "APA", value: "apa" },
  { label: "Chicago", value: "chicago" },
  { label: "Harvard", value: "harvard" },
  { label: "IEEE", value: "ieee" },
  { label: "MLA", value: "mla" },
  { label: "Vancouver", value: "vancouver" },
];

function CitationChanger({ paper }) {
  const [style, setStyle] = useState("ieee");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleChangeCitation() {
    if (!paper) return;

    setLoading(true);
    setError("");

    try {
      const data = await changeCitationStyle(paper, style);
      setResult(data.text);
    } catch (err) {
      setError(err.response?.data?.detail || "Could not change citation style");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="p-4 border-b border-greyBlue">
      <div className="flex items-center justify-between gap-3 mb-3">
        <h3 className="text-primary dark:text-softBlue font-semibold">
          Citation Style
        </h3>

        <select
          value={style}
          onChange={(event) => setStyle(event.target.value)}
          className="border border-greyBlue rounded-lg px-2 py-1 text-sm bg-white text-textPrimary dark:bg-slate-900 dark:text-gray-100"
        >
          {styles.map((item) => (
            <option key={item.value} value={item.value}>
              {item.label}
            </option>
          ))}
        </select>
      </div>

      <button
        onClick={handleChangeCitation}
        disabled={!paper || loading}
        className="bg-accent text-white text-sm px-3 py-2 rounded-lg disabled:opacity-50"
      >
        {loading ? "Changing..." : "Change Citations"}
      </button>

      {!paper && (
        <p className="mt-2 text-textSecondary text-sm">
          Upload and index a PDF to convert citation style.
        </p>
      )}

      {error && (
        <p className="mt-2 text-red-600 text-sm">
          {error}
        </p>
      )}

      {result && (
        <div className="mt-3 max-h-40 overflow-y-auto whitespace-pre-wrap rounded-lg border border-greyBlue bg-white/70 p-3 text-sm text-textPrimary dark:border-slate-700 dark:bg-slate-900 dark:text-gray-100">
          {result}
        </div>
      )}
    </div>
  );
}

export default CitationChanger;
