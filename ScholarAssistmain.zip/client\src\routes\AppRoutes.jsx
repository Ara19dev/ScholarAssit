import { BrowserRouter, Navigate, Routes, Route } from "react-router-dom"

import Landing from "../pages/Landing"
import Workspace from "../pages/Workspace"
import Dashboard from "../pages/Dashboard"
import CitationGenerator from "../components/citations/CitationGenerator"
import ComparePapers from "../pages/ComparePapers"
import AuthPage from "../pages/AuthPage"
import { useAuth } from "../context/useAuth"

function ProtectedRoute({ children }) {
  const { authenticated } = useAuth();
  return authenticated ? children : <Navigate to="/login" replace />;
}

function AppRoutes() {

  return (

    <BrowserRouter>

      <Routes>

        <Route path="/" element={<Landing />} />

        <Route path="/auth" element={<AuthPage />} />

        <Route path="/login" element={<AuthPage initialMode="login" />} />

        <Route path="/signup" element={<AuthPage initialMode="signup" />} />

        <Route path="/workspace" element={<ProtectedRoute><Workspace /></ProtectedRoute>} />

        <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />

        <Route path="/citation" element={<ProtectedRoute><CitationGenerator /></ProtectedRoute>} />

        <Route path="/compare" element={<ProtectedRoute><ComparePapers /></ProtectedRoute>} />

      </Routes>

    </BrowserRouter>

  )
}

export default AppRoutes
