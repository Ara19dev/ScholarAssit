AI_QUOTA_MESSAGE = "AI quota exceeded. Try again later or update Gemini API key."


class AIQuotaExceededError(Exception):
    pass


def is_quota_error(error):
    message = str(error).lower()

    return any(
        marker in message
        for marker in [
            "quota",
            "rate limit",
            "resource_exhausted",
            "429",
        ]
    )


def raise_friendly_ai_error(error):
    if is_quota_error(error):
        raise AIQuotaExceededError(AI_QUOTA_MESSAGE) from error

    raise error
