import { useEffect, useMemo, useState } from "react";

import { fetchPaperPdf } from "../../lib/nodeApi";

const aiBaseUrl = import.meta.env.VITE_API_BASE_URL || "http://127.0.0.1:8000";

function PaperViewer({ file, paper }) {
  const [mongoPdfUrl, setMongoPdfUrl] = useState("");
  const [mongoPdfError, setMongoPdfError] = useState("");
  const fileUrl = useMemo(() => {
    if (!file) return "";
    return URL.createObjectURL(file);
  }, [file]);

  const persistedUrl = paper
    ? `${aiBaseUrl}/paper/file/${encodeURIComponent(paper)}`
    : "";

  const viewerUrl = fileUrl || mongoPdfUrl || persistedUrl;

  useEffect(() => {
    return () => {
      if (fileUrl) {
        URL.revokeObjectURL(fileUrl);
      }
    };
  }, [fileUrl]);

  useEffect(() => {
    let objectUrl = "";
    let cancelled = false;

    async function loadMongoPdf() {
      if (file || !paper) {
        setMongoPdfUrl("");
        setMongoPdfError("");
        return;
      }

      try {
        const blob = await fetchPaperPdf(paper);

        if (cancelled) return;

        objectUrl = URL.createObjectURL(blob);
        setMongoPdfUrl(objectUrl);
        setMongoPdfError("");
      } catch {
        if (!cancelled) {
          setMongoPdfUrl("");
          setMongoPdfError("PDF was not found in MongoDB, falling back to FastAPI local preview.");
        }
      }
    }

    loadMongoPdf();

    return () => {
      cancelled = true;
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
      }
    };
  }, [file, paper]);

  if (!viewerUrl) {
    return (
      <div className="flex h-full min-h-[24rem] items-center justify-center p-4 text-center text-textSecondary">
        Upload or select a saved paper to preview the PDF.
      </div>
    );
  }

  return (
    <div className="h-full">
      {!file && paper && (
        <div className="border-b border-greyBlue bg-white px-3 py-2 text-sm text-textSecondary dark:bg-slate-900">
          {mongoPdfUrl
            ? "Loaded PDF from MongoDB."
            : mongoPdfError || "If the preview shows a JSON error, restart the FastAPI backend so the PDF file route is active."}
          <a
            href={viewerUrl}
            target="_blank"
            rel="noreferrer"
            className="ml-2 text-accent underline dark:text-softBlue"
          >
            Open PDF
          </a>
        </div>
      )}
      <iframe
        src={viewerUrl}
        title={file?.name || paper}
        className="h-full min-h-[28rem] w-full bg-white sm:min-h-[36rem]"
      />
    </div>
  );
}

export default PaperViewer;
