import { useEffect, useState } from "react";

import { fetchNote, saveNote } from "../../lib/nodeApi";

function NoteEditor({ paper }) {

  const [note, setNote] = useState("");
  const [status, setStatus] = useState("");

  useEffect(() => {
    async function loadNote() {
      if (!paper) {
        setNote("");
        return;
      }

      const saved = await fetchNote(paper);
      setNote(saved);
    }

    loadNote();
  }, [paper]);

  async function handleSave() {
    if (!paper) return;
    await saveNote(paper, note);
    setStatus("Saved");
    setTimeout(() => setStatus(""), 1500);
  }

  return (
    <div className="min-h-0 flex-1 border-t border-greyBlue bg-gray-100 p-3 dark:bg-[#0B1120] sm:p-4">

      <h3 className="text-primary dark:text-softBlue font-semibold mb-2">
        Research Notes
      </h3>

      <textarea
        value={note}
        onChange={(e) => setNote(e.target.value)}
        placeholder="Write notes about this paper..."
        className="h-32 w-full rounded-lg border border-greyBlue bg-white p-3 text-textPrimary placeholder:text-textSecondary dark:bg-slate-900 dark:text-gray-100 dark:placeholder:text-gray-400"
      />

      <button
        onClick={handleSave}
        disabled={!paper}
        className="mt-3 rounded-lg bg-primary px-4 py-2 text-white disabled:opacity-50"
      >
        Save Note
      </button>

      {status && (
        <span className="ml-3 text-sm text-textSecondary dark:text-softBlue">
          {status}
        </span>
      )}

    </div>
  );
}

export default NoteEditor;
