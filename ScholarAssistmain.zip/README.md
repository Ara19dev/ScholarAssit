# Scholar Assist

Scholar Assist is a research-paper workspace with a React client, a Node/Express account API, and a FastAPI AI/PDF service.

## Project Structure

```text
client/       React + Vite frontend
api-server/   Node + Express + MongoDB API for auth, user data, notes, history, and GridFS PDF storage
ai-service/   FastAPI service for PDF ingestion, extraction, FAISS indexing, Gemini features, Q&A, summaries, plagiarism, and comparison
```

## Local Development

Open the project folder in VS Code. The commands below use `<project-folder>` as a placeholder for wherever this repository lives on your machine.

### 1. Environment Files

Create `api-server/.env`.

```text
PORT=5000
MONGO_URI=mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net/Users?retryWrites=true&w=majority
JWT_SECRET=replace-with-a-long-random-secret
CLIENT_ORIGIN=http://localhost:5173
```

Create `ai-service/.env`.

```text
HF_API_KEY=your-huggingface-key
GEMINI_API_KEY=your-gemini-key
```

Frontend environment values are optional. Create `client/.env` only if the URLs differ:

```text
VITE_API_BASE_URL=http://localhost:8000
VITE_NODE_API_BASE_URL=http://localhost:5000
```

### 2. Start The Services

Terminal 1, AI/PDF service:

```powershell
cd <project-folder>\ai-service
.\.venv\Scripts\activate
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```

Terminal 2, Node API:

```powershell
cd <project-folder>\api-server
npm install
npm run dev
```

Terminal 3, React client:

```powershell
cd <project-folder>\client
npm install
npm run dev
```

Open:

```text
http://127.0.0.1:5173
```

## Verification

```powershell
cd <project-folder>\client
npm run lint
npm run build

cd <project-folder>\api-server
node --check src\index.js
node --check src\models.js

cd <project-folder>\ai-service
.\.venv\Scripts\activate
python -m compileall app
```

## Runtime Storage

- MongoDB Atlas stores users, password hashes, notes, activity, paper metadata, extracted text, citation state, and PDFs through GridFS.
- `ai-service/data/uploads` and `ai-service/data/faiss_index` are local runtime development folders and are ignored by Git.
