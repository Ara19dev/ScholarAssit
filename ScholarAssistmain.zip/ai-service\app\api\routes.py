from pathlib import Path

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse

from app.ingestion.pdf_loader import load_pdf
from app.ingestion.chunker import chunk_text
from app.embeddings.embedder import get_embedding
from app.config import DATA_DIR, GEMINI_API_KEY, LLM_MODEL
from app.vectorstore.faiss_store import add_embeddings
from app.vectorstore.faiss_store import get_all_papers
from app.vectorstore.faiss_store import get_chunks_for_paper
from app.vectorstore.faiss_store import get_paper_text
from app.vectorstore.faiss_store import search
from app.rag.ai_features import change_citation_style
from app.rag.ai_features import generate_internet_plagiarism_report
from app.rag.ai_features import SUPPORTED_CITATION_STYLES
from app.rag.errors import AI_QUOTA_MESSAGE
from app.rag.errors import AIQuotaExceededError
from app.rag.errors import raise_friendly_ai_error
from app.rag.qa_chain import generate_answer
from app.rag.qa_chain import generate_summary

router = APIRouter()
upload_dir = DATA_DIR / "uploads"


def _ai_quota_response():
    raise HTTPException(status_code=429, detail=AI_QUOTA_MESSAGE)


def _get_paper_text_or_404(paper):
    chunks = get_chunks_for_paper(paper)

    if not chunks:
        raise HTTPException(status_code=404, detail=f"No indexed chunks found for paper: {paper}")

    text = get_paper_text(paper)

    return text, chunks


def _resolve_uploaded_pdf(paper):
    filename = Path(paper).name
    direct_path = upload_dir / filename

    if direct_path.exists():
        return direct_path

    if not upload_dir.exists():
        return None

    normalized = filename.lower()
    stem = Path(filename).stem.lower()

    for candidate in upload_dir.glob("*.pdf"):
        if candidate.name.lower() == normalized or candidate.stem.lower() == stem:
            return candidate

    return None


def _word_similarity(first_text, second_text):
    first_words = set(first_text.lower().split())
    second_words = set(second_text.lower().split())

    if not first_words or not second_words:
        return 0

    return round((len(first_words & second_words) / len(first_words | second_words)) * 100, 2)


@router.post("/ingest")
async def ingest(file: UploadFile = File(...)):

    filename = Path(file.filename or "").name

    if not filename:
        raise HTTPException(status_code=400, detail="Uploaded file needs a filename")

    if Path(filename).suffix.lower() != ".pdf":
        raise HTTPException(status_code=400, detail="Only PDF uploads are supported")

    upload_dir.mkdir(parents=True, exist_ok=True)
    file_path = upload_dir / filename

    with file_path.open("wb") as f:
        f.write(await file.read())

    pages = load_pdf(file_path)

    chunks = chunk_text(pages)

    if not chunks:
        raise HTTPException(status_code=400, detail="No extractable text found in PDF")

    texts = [c["text"] for c in chunks]
    page_numbers = [c["page"] for c in chunks]

    embeddings = [get_embedding(text) for text in texts]

    full_text = "\n\n".join(
        f"Page {page['page']}\n{page['text']}"
        for page in pages
    )

    add_embeddings(embeddings, texts, page_numbers, filename, full_text)

    return {
        "status": "paper indexed",
        "paper": filename,
        "chunks": len(chunks),
        "extracted_text": full_text,
    }


@router.post("/ask")
async def ask(question: str = Form(...), paper: str = Form(...)):

    query_embedding = get_embedding(question)

    filtered_chunks = search(query_embedding, paper=paper)

    if not filtered_chunks:
        raise HTTPException(status_code=404, detail=f"No indexed chunks found for paper: {paper}")

    try:
        answer = generate_answer(question, filtered_chunks)
    except AIQuotaExceededError:
        _ai_quota_response()

    return {"answer": answer, "sources": filtered_chunks}

@router.post("/summary")
async def summarize(paper: str = Form(...)):

    _, chunks = _get_paper_text_or_404(paper)

    try:
        summary = generate_summary(chunks)
    except AIQuotaExceededError:
        _ai_quota_response()

    return {"summary": summary}


@router.post("/compare")
async def compare_papers(
    paper_a: str | None = Form(None),
    paper_b: str | None = Form(None),
):

    papers = get_all_papers()

    if len(papers) < 2:
        raise HTTPException(status_code=400, detail="At least two indexed papers are needed for comparison")

    comparison_context = ""
    selected_papers = papers

    similarity = None

    if paper_a and paper_b:
        if paper_a == paper_b:
            raise HTTPException(status_code=400, detail="Choose two different papers")

        first_text, first_chunks = _get_paper_text_or_404(paper_a)
        second_text, second_chunks = _get_paper_text_or_404(paper_b)
        similarity = _word_similarity(first_text, second_text)
        selected_papers = {
            paper_a: first_chunks,
            paper_b: second_chunks,
        }

    for paper, chunks in selected_papers.items():

        comparison_context += f"\nPaper: {paper}\n"

        for c in chunks[:5]:
            comparison_context += f"(Page {c['page']}): {c['text']}\n"

    prompt = f"""
Compare the following research papers. Keep the response concise, structured, and easy to render in a UI.
Do not use markdown tables. Do not add extra headings. Do not use hash-prefixed markdown headings.

Return exactly these plain-text headings, each followed by 2-4 short, readable bullet points.
Use "- " for bullets. Do not use markdown tables, pipe characters, HTML, or hash headings.
Overview:
Methodology Comparison:
Results Comparison:
Contributions:
Similarities:
Differences:
Research Gaps:
Recommendation:

{comparison_context}
"""

    from google import genai

    client = genai.Client(api_key=GEMINI_API_KEY)

    try:
        response = client.models.generate_content(
            model=LLM_MODEL,
            contents=prompt
        )
    except Exception as error:
        try:
            raise_friendly_ai_error(error)
        except AIQuotaExceededError:
            _ai_quota_response()

    return {
        "comparison": response.text,
        "similarity": similarity,
        "papers": list(selected_papers.keys()),
    }


@router.get("/papers")
async def list_papers():

    return {"papers": list(get_all_papers().keys())}


@router.get("/paper/text")
async def paper_text(paper: str):

    extracted_text, _ = _get_paper_text_or_404(paper)

    return {
        "paper": paper,
        "extracted_text": extracted_text,
    }


@router.get("/paper/file")
async def paper_file(paper: str):

    filename = Path(paper).name
    file_path = _resolve_uploaded_pdf(filename)

    if not file_path:
        raise HTTPException(status_code=404, detail=f"PDF file not found for paper: {filename}")

    return FileResponse(
        file_path,
        media_type="application/pdf",
        filename=file_path.name,
        content_disposition_type="inline",
    )


@router.get("/paper/file/{paper}")
async def paper_file_by_path(paper: str):

    return await paper_file(paper)


@router.post("/plagiarism")
async def detect_plagiarism(
    paper: str = Form(...),
):

    source_text, _ = _get_paper_text_or_404(paper)
    try:
        result = generate_internet_plagiarism_report(paper, source_text)
    except AIQuotaExceededError:
        _ai_quota_response()

    return {
        "paper": paper,
        "report": result["report"],
        "sources": result["sources"],
    }


@router.post("/citation/change")
async def change_citation(
    paper: str = Form(...),
    citation_style: str = Form(...),
):

    extracted_text, _ = _get_paper_text_or_404(paper)

    try:
        revised_text = change_citation_style(extracted_text, citation_style)
    except AIQuotaExceededError:
        _ai_quota_response()
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "paper": paper,
        "citation_style": citation_style,
        "supported_styles": SUPPORTED_CITATION_STYLES,
        "extracted_text": extracted_text,
        "text": revised_text,
    }
