import { GitCompare, Home, LayoutDashboard, LogOut, Menu } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";

import { useAuth } from "../../context/useAuth";

function Sidebar({ papers = [], selectedPaper = "", onSelectPaper }) {
  const { logout, user } = useAuth();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside className={`${collapsed ? "lg:w-20" : "lg:w-80"} max-h-[18rem] w-full shrink-0 overflow-y-auto border-b border-greyBlue bg-white text-textPrimary transition-all duration-300 dark:border-slate-800 dark:bg-[#0B1120] dark:text-gray-100 sm:max-h-80 lg:h-full lg:max-h-none lg:border-b-0 lg:border-r`}>
      <div className="flex h-full flex-col p-3 sm:p-4">
        <div className="mb-3 lg:mb-6">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className={`${collapsed ? "lg:justify-center" : ""} flex w-full items-center gap-3 rounded-lg p-2 text-sm font-medium hover:bg-[#D0E3FF] dark:hover:bg-slate-800`}
            aria-label="Collapse sidebar"
            title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            <Menu size={20} />
            <span className={collapsed ? "lg:hidden" : ""}>Hide menu</span>
          </button>
        </div>

        <nav className="no-scrollbar flex gap-2 overflow-x-auto lg:block lg:space-y-1 lg:overflow-visible">
              <Link
                to="/"
                className={`${collapsed ? "lg:justify-center" : ""} flex shrink-0 items-center gap-3 rounded-lg p-3 text-sm font-medium hover:bg-[#D0E3FF] dark:hover:bg-slate-800`}
                title="Home"
              >
                <Home size={18} />
                <span className={collapsed ? "lg:hidden" : ""}>Home</span>
              </Link>

              <Link
                to="/dashboard"
                className={`${collapsed ? "lg:justify-center" : ""} flex shrink-0 items-center gap-3 rounded-lg p-3 text-sm font-medium hover:bg-[#D0E3FF] dark:hover:bg-slate-800`}
                title="Dashboard"
              >
                <LayoutDashboard size={18} />
                <span className={collapsed ? "lg:hidden" : ""}>Dashboard</span>
              </Link>

              <Link
                to="/compare"
                className={`${collapsed ? "lg:justify-center" : ""} flex shrink-0 items-center gap-3 rounded-lg p-3 text-sm font-medium hover:bg-[#D0E3FF] dark:hover:bg-slate-800`}
                title="Compare Papers"
              >
                <GitCompare size={18} />
                <span className={collapsed ? "lg:hidden" : ""}>Compare Papers</span>
              </Link>
            </nav>

        <div className={collapsed ? "lg:hidden" : ""}>
          <>
            <div className="mt-4 lg:mt-7">
              <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-textSecondary dark:text-gray-400">
                Your Papers
              </p>

              <div className="no-scrollbar flex gap-2 overflow-x-auto lg:block lg:space-y-2 lg:overflow-visible">
                {papers.map((paper) => (
                  <button
                    key={paper._id || paper.filename}
                    onClick={() => onSelectPaper?.(paper)}
                    className={`min-w-44 rounded-lg p-3 text-left text-sm transition lg:w-full ${
                      selectedPaper === paper.filename
                        ? "bg-[#334EAC] text-white"
                        : "bg-[#F5F8FF] text-textPrimary hover:bg-[#D0E3FF] dark:bg-slate-900 dark:text-gray-100 dark:hover:bg-slate-800"
                    }`}
                    title={paper.originalName || paper.filename}
                  >
                    <span className="block truncate font-medium">
                      {paper.originalName || paper.filename}
                    </span>
                  </button>
                ))}

                {papers.length === 0 && (
                  <p className="rounded-lg border border-dashed border-greyBlue p-3 text-sm text-textSecondary dark:border-slate-700 dark:text-gray-400">
                    No saved papers yet.
                  </p>
                )}
              </div>
            </div>

            <div className="mt-4 border-t border-greyBlue pt-4 text-sm dark:border-slate-800 lg:mt-auto">
              <p className="mb-3 truncate text-textSecondary dark:text-gray-400">
                {user?.email}
              </p>

              <button
                onClick={logout}
                className="flex items-center gap-2 rounded-lg bg-[#E7EEF9] px-3 py-2 text-textPrimary hover:bg-[#D0E3FF] dark:bg-slate-800 dark:text-gray-100 dark:hover:bg-slate-700"
              >
                <LogOut size={16} />
                Log Out
              </button>
            </div>
          </>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;
