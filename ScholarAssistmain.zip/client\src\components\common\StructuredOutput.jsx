const defaultHeadings = [
  "Overview",
  "AI Comparison",
  "Problem",
  "Method",
  "Dataset",
  "Results",
  "Limitations",
  "Research Gap",
  "Overall risk",
  "Likely internet overlap",
  "Matched web sources with URLs",
  "Reasoning",
  "Suggested rewrite guidance",
  "Answer",
  "Evidence",
  "Sources",
  "Methodology Comparison",
  "Results Comparison",
  "Contributions",
  "Similarities",
  "Differences",
  "Recommendation",
];

function cleanText(value = "") {
  return value
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/^#{1,6}\s+/gm, "")
    .replace(/\*\*/g, "")
    .replace(/\*/g, "")
    .replace(/`/g, "")
    .replace(/\s+\n/g, "\n")
    .trim();
}

function splitTableRow(line) {
  return line
    .trim()
    .replace(/^\|/, "")
    .replace(/\|$/, "")
    .split("|")
    .map((cell) => cleanText(cell.trim()));
}

function parseMarkdownTables(text) {
  const lines = text.split(/\r?\n/);
  const sections = [];
  let index = 0;

  while (index < lines.length) {
    if (!lines[index].trim().startsWith("|")) {
      index += 1;
      continue;
    }

    const tableLines = [];

    while (index < lines.length && lines[index].trim().startsWith("|")) {
      tableLines.push(lines[index]);
      index += 1;
    }

    const rows = tableLines
      .filter((line) => !/^\|?\s*:?-{3,}:?/.test(line.trim()))
      .map(splitTableRow)
      .filter((cells) => cells.length >= 2);

    const [headers, ...bodyRows] = rows;

    bodyRows.forEach((cells) => {
      const title = cells[0] || "Comparison Point";
      const body = cells
        .slice(1)
        .map((cell, cellIndex) => {
          const label = headers?.[cellIndex + 1] || `Paper ${cellIndex + 1}`;
          return `${label}: ${cell}`;
        })
        .join("\n\n");

      if (body) {
        sections.push({ title, body });
      }
    });
  }

  return sections;
}

function parseStructuredOutput(text = "", headings = defaultHeadings) {
  const cleaned = cleanText(text);

  if (!cleaned) return [];

  const tableSections = parseMarkdownTables(cleaned);

  if (tableSections.length) {
    const summary = cleaned
      .split(/\r?\n/)
      .filter((line) => {
        const trimmed = line.trim();
        return trimmed && !trimmed.startsWith("|") && !/^Comparison of Research Papers$/i.test(trimmed);
      })
      .join("\n");

    return [
      ...(summary ? [{ title: "Summary", body: summary }] : []),
      ...tableSections,
    ];
  }

  const pattern = new RegExp(`(?:^|\\n)(${headings.join("|")}):`, "gi");
  const matches = [...cleaned.matchAll(pattern)];

  if (!matches.length) {
    return [{ title: "Response", body: cleaned }];
  }

  return matches
    .map((match, index) => {
      const start = match.index + match[0].length;
      const end = matches[index + 1]?.index ?? cleaned.length;
      return {
        title: match[1],
        body: cleanText(cleaned.slice(start, end)),
      };
    })
    .filter((section) => section.body);
}

function StructuredOutput({ text, headings, empty = "No output yet.", compact = false }) {
  const sections = parseStructuredOutput(text, headings);

  if (!sections.length) {
    return <p className="text-sm text-textSecondary dark:text-blue-100">{empty}</p>;
  }

  return (
    <div className={compact ? "space-y-2" : "space-y-4"}>
      {sections.map((section, index) => (
        <section
          key={`${section.title}-${index}`}
          className="rounded-lg border border-greyBlue bg-white/80 p-3 dark:border-slate-700 dark:bg-slate-900"
        >
          <h4 className="mb-1 font-semibold text-primary dark:text-softBlue">
            {section.title}
          </h4>
          <p className="whitespace-pre-wrap text-sm leading-relaxed text-textPrimary dark:text-gray-100">
            {section.body}
          </p>
        </section>
      ))}
    </div>
  );
}

export default StructuredOutput;
