import { useState } from "react";

import { askPaper } from "../../lib/api";

function AIAssistant({ paper }) {

  const [messages, setMessages] = useState([
    { role: "assistant", text: "Hello! Ask me anything about this paper." }
  ]);

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  async function sendMessage() {

    if (!input.trim() || !paper || loading) return;

    const newMessages = [
      ...messages,
      { role: "user", text: input }
    ];

    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const result = await askPaper(input, paper);
      setMessages([
        ...newMessages,
        { role: "assistant", text: result.answer }
      ]);
    } catch (err) {
      setMessages([
        ...newMessages,
        {
          role: "assistant",
          text: err.response?.data?.detail || "I could not answer from this paper."
        }
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="h-full flex flex-col">

      <div className="p-4 border-b border-greyBlue">

        <h2 className="text-lg font-semibold text-primary dark:text-softBlue">
          AI Research Assistant
        </h2>

      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">

        {messages.map((msg, index) => (

          <div
            key={index}
            className={`p-3 rounded-lg max-w-xs ${
              msg.role === "user"
                ? "bg-primary text-white ml-auto"
                : "bg-bgSoft text-textPrimary dark:bg-slate-800 dark:text-gray-100"
            }`}
          >
            {msg.text}
          </div>

        ))}

      </div>

      <div className="p-4 border-t border-greyBlue flex gap-2">

        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={paper ? "Ask a question about the paper..." : "Upload a PDF first..."}
          disabled={!paper || loading}
          className="flex-1 border border-greyBlue rounded-lg px-3 py-2 outline-none focus:border-primary bg-white text-textPrimary placeholder:text-textSecondary disabled:bg-gray-100 dark:bg-slate-900 dark:text-gray-100 dark:placeholder:text-gray-400 dark:disabled:bg-slate-800"
        />

        <button
          onClick={sendMessage}
          disabled={!paper || loading}
          className="bg-primary text-white px-4 rounded-lg hover:bg-primaryHover disabled:opacity-50"
        >
          {loading ? "..." : "Send"}
        </button>

      </div>

    </div>
  );
}

export default AIAssistant;
