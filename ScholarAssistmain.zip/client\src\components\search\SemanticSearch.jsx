import { Search } from "lucide-react";
import { useState } from "react";

function SemanticSearch({ compact = false, onSearch }) {

  const [query, setQuery] = useState("");

  function handleSearch() {
    onSearch?.(query);
  }

  return (
    <div className={compact ? "w-full" : "border-b border-greyBlue p-3 sm:p-4"}>

      <div className="flex overflow-hidden rounded-lg border border-greyBlue bg-white dark:border-slate-700 dark:bg-slate-900">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(event) => { if (event.key === "Enter") handleSearch(); }}
          placeholder="Search across your papers..."
          className="min-w-0 flex-1 bg-transparent px-3 py-2 text-textPrimary outline-none placeholder:text-textSecondary dark:text-gray-100 dark:placeholder:text-gray-400"
        />

        <button
          onClick={handleSearch}
          className="flex w-12 shrink-0 items-center justify-center bg-accent text-white"
          aria-label="Search"
          title="Search"
        >
          <Search size={18} />
        </button>
      </div>

    </div>
  );
}

export default SemanticSearch;
