function RecentActivity({ activities = [] }) {

  return (
    <div className="rounded-xl border border-greyBlue bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-[#0B1120] sm:p-6">

      <h3 className="mb-4 font-semibold text-primary dark:text-softBlue">
        Recent Activity
      </h3>

      <ul className="space-y-3">

        {activities.slice(0, 8).map((item) => (
          <li key={item._id} className="rounded-lg border border-greyBlue p-3 text-textSecondary dark:border-slate-700 dark:bg-slate-900 dark:text-blue-100">
            <span className="block font-medium text-textPrimary dark:text-white">
              {item.action}
            </span>
            {item.detail || "No details"}
          </li>
        ))}

        {activities.length === 0 && (
          <li className="text-textSecondary dark:text-blue-100">
            No activity yet.
          </li>
        )}

      </ul>

    </div>
  );
}

export default RecentActivity;
