import { Link, useLocation } from "react-router-dom";
import { BookOpen } from "lucide-react";

import { useAuth } from "../../context/useAuth";
import DarkModeToggle from "./DarkModeToggle";

function TopNavbar({ transparent = false, showThemeToggle = true }) {
  const { authenticated, logout } = useAuth();
  const { pathname } = useLocation();
  const showWorkspaceLink = authenticated && !pathname.startsWith("/workspace");

  return (
    <nav className={`relative z-10 flex items-center justify-between gap-3 px-3 py-3 sm:px-6 sm:py-4 lg:px-8 ${transparent ? "border-b border-[#334EAC]/15 bg-white/45 text-textPrimary backdrop-blur-lg dark:border-white/10 dark:bg-white/5 dark:text-white" : "border-b border-greyBlue bg-white text-textPrimary dark:border-slate-700 dark:bg-[#0B1120] dark:text-gray-100"}`}>
      <Link to="/" className="flex min-w-0 items-center gap-2 font-semibold sm:gap-3">
        <BookOpen size={26} className="shrink-0 text-softBlue" />
        <span className="truncate text-base sm:text-xl">Scholar Assist</span>
      </Link>

      <div className="flex shrink-0 items-center gap-1.5 sm:gap-3">
        {authenticated ? (
          <>
            {showWorkspaceLink && (
              <Link to="/workspace">
                <button className="rounded-lg bg-[#334EAC] px-2.5 py-2 text-xs text-white hover:bg-[#567CBD] sm:px-5 sm:text-base">
                  Workspace
                </button>
              </Link>
            )}
            <button
              onClick={logout}
              className={`rounded-lg border px-2.5 py-2 text-xs sm:px-5 sm:text-base ${transparent ? "border-[#334EAC]/30 text-textPrimary hover:border-[#334EAC] dark:border-[#A9CBE0] dark:text-white dark:hover:border-white" : "border-greyBlue text-textPrimary hover:border-[#334EAC] dark:border-slate-600 dark:text-gray-100 dark:hover:border-softBlue"}`}
            >
              Logout
            </button>
          </>
        ) : (
          <Link to="/auth">
            <button className="rounded-lg bg-[#334EAC] px-2.5 py-2 text-xs text-white hover:bg-[#567CBD] sm:px-5 sm:text-base">
              Login / Signup
            </button>
          </Link>
        )}
        {showThemeToggle && <DarkModeToggle />}
      </div>
    </nav>
  );
}

export default TopNavbar;
