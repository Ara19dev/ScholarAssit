import "dotenv/config";
import bcrypt from "bcryptjs";
import cors from "cors";
import express from "express";
import mongoose from "mongoose";

import { requireAuth, signToken } from "./auth.js";
import { History, Note, Paper, User } from "./models.js";

const app = express();
const port = process.env.PORT || 5000;
const allowedOrigins = (process.env.CLIENT_ORIGIN || "http://localhost:5173,http://127.0.0.1:5173")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);
const isLocalDevOrigin = (origin = "") => /^http:\/\/(localhost|127\.0\.0\.1):\d+$/.test(origin);

app.use(cors({
  origin(origin, callback) {
    if (!origin || allowedOrigins.includes(origin) || (process.env.NODE_ENV !== "production" && isLocalDevOrigin(origin))) {
      return callback(null, true);
    }

    return callback(new Error(`CORS blocked origin: ${origin}`));
  },
  credentials: true,
}));
app.use(express.json({ limit: "2mb" }));

function getPdfBucket() {
  return new mongoose.mongo.GridFSBucket(mongoose.connection.db, {
    bucketName: "paper_pdfs",
  });
}

function streamToGridFs(bucket, filename, buffer, metadata) {
  return new Promise((resolve, reject) => {
    const uploadStream = bucket.openUploadStream(filename, {
      contentType: "application/pdf",
      metadata,
    });

    uploadStream.once("finish", () => resolve(uploadStream.id));
    uploadStream.once("error", reject);
    uploadStream.end(buffer);
  });
}

async function recordHistory(user, action, detail = "", paper = "") {
  await History.create({ user, action, detail, paper });
}

app.get("/health", (req, res) => {
  res.json({ ok: true });
});

app.post("/auth/signup", async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ message: "Name, email, and password are required" });
  }

  if (password.length < 6) {
    return res.status(400).json({ message: "Password must be at least 6 characters" });
  }

  const existing = await User.findOne({ email });

  if (existing) {
    return res.status(409).json({ message: "An account with this email already exists" });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await User.create({ name, email, passwordHash });
  await recordHistory(user._id, "signup", "Account created");

  res.status(201).json({
    token: signToken(user),
    user: { id: user._id, name: user.name, email: user.email },
  });
});

app.post("/auth/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });

  if (!user) {
    return res.status(401).json({ message: "Invalid email or password" });
  }

  const valid = await bcrypt.compare(password, user.passwordHash);

  if (!valid) {
    return res.status(401).json({ message: "Invalid email or password" });
  }

  await recordHistory(user._id, "login", "Signed in");

  res.json({
    token: signToken(user),
    user: { id: user._id, name: user.name, email: user.email },
  });
});

app.get("/auth/me", requireAuth, async (req, res) => {
  const user = await User.findById(req.userId).select("name email");

  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }

  res.json({ user });
});

app.get("/papers", requireAuth, async (req, res) => {
  const papers = await Paper.find({ user: req.userId }).sort({ updatedAt: -1 });
  res.json({ papers });
});

app.post("/papers", requireAuth, async (req, res) => {
  const { filename, originalName, chunks, extractedText, originalCitationStyle, citationStyle, lastCitationStyle } = req.body;

  if (!filename || !originalName) {
    return res.status(400).json({ message: "filename and originalName are required" });
  }

  const paper = await Paper.findOneAndUpdate(
    { user: req.userId, filename },
    {
      user: req.userId,
      filename,
      originalName,
      chunks: chunks || 0,
      extractedText: extractedText || "",
      originalCitationStyle: originalCitationStyle || "",
      citationStyle: citationStyle || "",
      lastCitationStyle: lastCitationStyle || "",
    },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );

  await recordHistory(req.userId, "upload", `Uploaded ${originalName}`, filename);

  res.status(201).json({ paper });
});

app.patch("/papers/:filename/text", requireAuth, async (req, res) => {
  const paper = await Paper.findOneAndUpdate(
    { user: req.userId, filename: req.params.filename },
    {
      extractedText: req.body.extractedText || "",
      ...(req.body.originalCitationStyle ? { originalCitationStyle: req.body.originalCitationStyle } : {}),
      ...(req.body.citationStyle ? { citationStyle: req.body.citationStyle } : {}),
      ...(req.body.lastCitationStyle ? { lastCitationStyle: req.body.lastCitationStyle } : {}),
    },
    { new: true }
  );

  if (!paper) {
    return res.status(404).json({ message: "Paper not found" });
  }

  await recordHistory(req.userId, "text-save", `Saved modified extracted text for ${req.params.filename}`, req.params.filename);

  res.json({ paper });
});

app.post(
  "/papers/:filename/file",
  requireAuth,
  express.raw({ type: ["application/pdf", "application/octet-stream"], limit: "50mb" }),
  async (req, res) => {
    const filename = req.params.filename;
    const originalName = req.header("x-original-name") || filename;

    if (!Buffer.isBuffer(req.body) || req.body.length === 0) {
      return res.status(400).json({ message: "PDF file body is required" });
    }

    const bucket = getPdfBucket();
    const existingPaper = await Paper.findOne({ user: req.userId, filename });

    if (existingPaper?.pdfFileId) {
      try {
        await bucket.delete(existingPaper.pdfFileId);
      } catch {
        // The metadata is still updated below even if the old GridFS object is already gone.
      }
    }

    const pdfFileId = await streamToGridFs(
      bucket,
      `${req.userId}-${filename}`,
      req.body,
      {
        user: req.userId.toString(),
        filename,
        originalName,
      }
    );

    const paper = await Paper.findOneAndUpdate(
      { user: req.userId, filename },
      {
        user: req.userId,
        filename,
        originalName,
        pdfFileId,
        pdfContentType: "application/pdf",
        pdfSize: req.body.length,
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    await recordHistory(req.userId, "pdf-save", `Saved PDF file for ${originalName}`, filename);

    res.status(201).json({ paper });
  }
);

app.get("/papers/:filename/file", requireAuth, async (req, res) => {
  const paper = await Paper.findOne({ user: req.userId, filename: req.params.filename });

  if (!paper?.pdfFileId) {
    return res.status(404).json({ message: "PDF file not found in MongoDB" });
  }

  res.setHeader("Content-Type", paper.pdfContentType || "application/pdf");
  res.setHeader("Content-Disposition", `inline; filename="${encodeURIComponent(paper.originalName || paper.filename)}"`);

  getPdfBucket()
    .openDownloadStream(paper.pdfFileId)
    .on("error", () => {
      if (!res.headersSent) {
        res.status(404).json({ message: "PDF file not found in GridFS" });
      } else {
        res.end();
      }
    })
    .pipe(res);
});

app.get("/notes/:paper", requireAuth, async (req, res) => {
  const note = await Note.findOne({ user: req.userId, paper: req.params.paper });
  res.json({ note: note?.body || "" });
});

app.put("/notes/:paper", requireAuth, async (req, res) => {
  const note = await Note.findOneAndUpdate(
    { user: req.userId, paper: req.params.paper },
    { user: req.userId, paper: req.params.paper, body: req.body.note || "" },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );

  await recordHistory(req.userId, "note", `Saved notes for ${req.params.paper}`, req.params.paper);

  res.json({ note: note.body });
});

app.post("/history", requireAuth, async (req, res) => {
  const { action, detail, paper } = req.body;

  if (!action) {
    return res.status(400).json({ message: "action is required" });
  }

  const item = await History.create({
    user: req.userId,
    action,
    detail: detail || "",
    paper: paper || "",
  });

  res.status(201).json({ history: item });
});

app.get("/history", requireAuth, async (req, res) => {
  const history = await History.find({ user: req.userId }).sort({ createdAt: -1 }).limit(50);
  res.json({ history });
});

mongoose
  .connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/scholar_assist")
  .then(() => {
    app.listen(port, () => {
      console.log(`Node API listening on http://127.0.0.1:${port}`);
    });
  })
  .catch((err) => {
    console.error("Mongo connection failed:", err.message);
    process.exit(1);
  });
