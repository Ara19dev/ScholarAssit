import { useState } from "react";

import { summarizePaper } from "../../lib/api";
import { tryRecordHistory } from "../../lib/nodeApi";
import StructuredOutput from "../common/StructuredOutput";

function SummaryPanel({ paper }) {

  const [summary, setSummary] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSummary() {
    if (!paper) return;

    setLoading(true);
    setError("");

    try {
      const result = await summarizePaper(paper);
      setSummary(result.summary);
      await tryRecordHistory("summary", `Generated summary for ${paper}`, paper);
    } catch (err) {
      setError(err.response?.data?.detail || "Could not generate summary");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="border-b border-greyBlue p-3 sm:p-4">

      <div className="mb-2 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h3 className="text-primary dark:text-softBlue font-semibold">
        AI Paper Summary
        </h3>

        <button
          onClick={handleSummary}
          disabled={!paper || loading}
          className="rounded-lg bg-primary px-3 py-2 text-sm text-white disabled:opacity-50"
        >
          {loading ? "Summarizing..." : "Generate"}
        </button>
      </div>

      {!paper && (
        <p className="text-textSecondary text-sm">
          Upload and index a PDF to generate its summary.
        </p>
      )}

      {error && (
        <p className="text-red-600 text-sm">
          {error}
        </p>
      )}

      {summary && (
        <div className="max-h-64 overflow-y-auto">
          <StructuredOutput text={summary} compact />
        </div>
      )}

    </div>
  );
}

export default SummaryPanel;
