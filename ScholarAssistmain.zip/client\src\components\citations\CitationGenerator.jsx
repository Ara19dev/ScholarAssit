import { useEffect, useState } from "react";

import { changeCitationStyle, fetchPapers } from "../../lib/api";

const styles = [
  { label: "American Chemical Society", value: "acs" },
  { label: "APA", value: "apa" },
  { label: "Chicago", value: "chicago" },
  { label: "Harvard", value: "harvard" },
  { label: "IEEE", value: "ieee" },
  { label: "MLA", value: "mla" },
  { label: "Vancouver", value: "vancouver" },
];

function CitationGenerator() {
  const [papers, setPapers] = useState([]);
  const [paper, setPaper] = useState("");
  const [style, setStyle] = useState("ieee");
  const [originalText, setOriginalText] = useState("");
  const [convertedText, setConvertedText] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadPapers() {
      try {
        const result = await fetchPapers();
        setPapers(result);
        setPaper(result[0] || "");
      } catch (err) {
        setError(err.response?.data?.detail || "Could not load uploaded PDFs");
      }
    }

    loadPapers();
  }, []);

  async function handleChangeCitation() {
    if (!paper) return;

    setLoading(true);
    setError("");

    try {
      const result = await changeCitationStyle(paper, style);
      setOriginalText(result.extracted_text);
      setConvertedText(result.text);
    } catch (err) {
      setError(err.response?.data?.detail || "Could not change citation style");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#081F5C] px-4 py-8 text-white sm:px-6 lg:px-10 lg:py-12">
      <div className="max-w-6xl mx-auto">
        <h1 className="mb-6 text-3xl font-bold sm:mb-8 sm:text-4xl">
          Citation Style Converter
        </h1>

        <div className="grid gap-6 md:grid-cols-[minmax(0,320px)_1fr]">
          <div className="rounded-xl bg-white/10 p-4 backdrop-blur-lg sm:p-6">
            <label className="block text-sm text-[#BAD6EB] mb-2">
              Uploaded PDF
            </label>

            <select
              className="w-full p-3 mb-4 rounded text-black"
              value={paper}
              onChange={(event) => setPaper(event.target.value)}
            >
              {papers.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </select>

            <label className="block text-sm text-[#BAD6EB] mb-2">
              Citation Style
            </label>

            <select
              className="w-full p-3 mb-4 rounded text-black"
              value={style}
              onChange={(event) => setStyle(event.target.value)}
            >
              {styles.map((item) => (
                <option key={item.value} value={item.value}>
                  {item.label}
                </option>
              ))}
            </select>

            <button
              onClick={handleChangeCitation}
              disabled={!paper || loading}
              className="w-full bg-[#334EAC] p-3 rounded-lg hover:bg-[#567CBD] transition disabled:opacity-50"
            >
              {loading ? "Converting..." : "Change Citation Style"}
            </button>

            {error && (
              <p className="mt-4 text-sm text-red-200">
                {error}
              </p>
            )}
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <section className="rounded-xl bg-white/10 p-4 backdrop-blur-lg sm:p-6">
              <h2 className="font-semibold mb-4 text-[#BAD6EB]">
                Extracted Text
              </h2>
              <div className="h-80 overflow-y-auto whitespace-pre-wrap text-sm sm:h-[32rem]">
                {originalText || "Choose a PDF and citation style to view extracted text."}
              </div>
            </section>

            <section className="rounded-xl bg-white/10 p-4 backdrop-blur-lg sm:p-6">
              <h2 className="font-semibold mb-4 text-[#BAD6EB]">
                Converted Text
              </h2>
              <div className="h-80 overflow-y-auto whitespace-pre-wrap text-sm sm:h-[32rem]">
                {convertedText || "Converted citation text will appear here."}
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CitationGenerator;
