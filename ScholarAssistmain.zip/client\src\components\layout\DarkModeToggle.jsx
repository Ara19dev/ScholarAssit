import { useEffect, useState } from "react"
import { motion as Motion } from "framer-motion"
import { Sun, Moon } from "lucide-react"

function DarkModeToggle(){

  const systemDark = window.matchMedia("(prefers-color-scheme: dark)").matches

  const [darkMode,setDarkMode] = useState(
    localStorage.getItem("theme")
      ? localStorage.getItem("theme") === "dark"
      : systemDark
  )

  useEffect(()=>{

    if(darkMode){
      document.documentElement.classList.add("dark")
      localStorage.setItem("theme","dark")
    } else {
      document.documentElement.classList.remove("dark")
      localStorage.setItem("theme","light")
    }

  },[darkMode])

  return(

    <button
      type="button"
      onClick={()=>setDarkMode(!darkMode)}
      aria-label="Toggle dark mode"
      className="relative w-14 h-7 bg-gray-300 dark:bg-[#334EAC] rounded-full cursor-pointer flex items-center"
    >

      <Motion.div
        layout
        transition={{type:"spring",stiffness:500,damping:30}}
        className="absolute w-6 h-6 bg-white dark:bg-[#0B1120] rounded-full shadow flex items-center justify-center"
        style={{left: darkMode ? "calc(100% - 26px)" : "2px"}}
      >

        {darkMode ? (
          <Moon size={14} className="text-[#BAD6EB]" />
        ) : (
          <Sun size={14} className="text-[#D97706]" />
        )}

      </Motion.div>

    </button>

  )
}

export default DarkModeToggle
