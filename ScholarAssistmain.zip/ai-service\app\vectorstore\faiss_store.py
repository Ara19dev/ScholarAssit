import faiss
import numpy as np
import pickle

from app.config import DATA_DIR

dimension = 384
store_dir = DATA_DIR / "faiss_index"
index_path = store_dir / "index.faiss"
metadata_path = store_dir / "metadata.pkl"

documents = []
pages = []
paper_names = []
paper_texts = {}


def _new_index():
    return faiss.IndexFlatL2(dimension)


index = _new_index()


def _load_store():
    global index, documents, pages, paper_names, paper_texts

    if not index_path.exists() or not metadata_path.exists():
        return

    try:
        loaded_index = faiss.read_index(str(index_path))

        with metadata_path.open("rb") as f:
            metadata = pickle.load(f)

        loaded_documents = metadata.get("documents", [])
        loaded_pages = metadata.get("pages", [])
        loaded_paper_names = metadata.get("paper_names", [])
        loaded_paper_texts = metadata.get("paper_texts", {})

        metadata_count = len(loaded_documents)

        if (
            loaded_index.d != dimension
            or loaded_index.ntotal != metadata_count
            or len(loaded_pages) != metadata_count
            or len(loaded_paper_names) != metadata_count
        ):
            return

        index = loaded_index
        documents = loaded_documents
        pages = loaded_pages
        paper_names = loaded_paper_names
        paper_texts = loaded_paper_texts
    except Exception:
        index = _new_index()
        documents = []
        pages = []
        paper_names = []
        paper_texts = {}


def _save_store():
    store_dir.mkdir(parents=True, exist_ok=True)
    faiss.write_index(index, str(index_path))

    with metadata_path.open("wb") as f:
        pickle.dump({
            "documents": documents,
            "pages": pages,
            "paper_names": paper_names,
            "paper_texts": paper_texts,
        }, f)


def add_embeddings(embeddings, texts, page_numbers, paper_name, full_text=None):

    global documents, pages, paper_names, paper_texts

    if not embeddings:
        return

    vectors = np.array(embeddings).astype("float32")

    index.add(vectors)

    documents.extend(texts)
    pages.extend(page_numbers)

    # store paper name for every chunk
    paper_names.extend([paper_name] * len(texts))

    if full_text:
        paper_texts[paper_name] = full_text

    _save_store()


def search(query_embedding, top_k=5, paper=None, exclude_paper=None):

    if index.ntotal == 0:
        return []

    candidate_count = min(index.ntotal, max(top_k, 1))

    if paper or exclude_paper:
        candidate_count = index.ntotal

    vector = np.array([query_embedding]).astype("float32")

    distances, indices = index.search(vector, candidate_count)

    results = []

    for distance, i in zip(distances[0], indices[0]):
        if i < 0:
            continue

        if paper and paper_names[i] != paper:
            continue

        if exclude_paper and paper_names[i] == exclude_paper:
            continue

        results.append({
            "text": documents[i],
            "page": pages[i],
            "paper": paper_names[i],
            "distance": float(distance),
        })

        if len(results) >= top_k:
            break

    return results


def get_chunks_for_paper(paper):
    return [
        {"text": text, "page": page, "paper": paper_name}
        for text, page, paper_name in zip(documents, pages, paper_names)
        if paper_name == paper
    ]


def get_paper_text(paper):
    if paper in paper_texts:
        return paper_texts[paper]

    chunks = get_chunks_for_paper(paper)
    return "\n\n".join(chunk["text"] for chunk in chunks)


def get_all_papers():
    papers = {}

    for text, page, paper_name in zip(documents, pages, paper_names):
        papers.setdefault(paper_name, []).append({
            "text": text,
            "page": page,
            "paper": paper_name,
        })

    return papers


_load_store()
