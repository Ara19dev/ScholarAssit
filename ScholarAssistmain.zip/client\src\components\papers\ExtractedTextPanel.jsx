import { useEffect, useRef, useState } from "react";

import { changeCitationStyle } from "../../lib/api";
import { tryRecordHistory, trySaveExtractedText } from "../../lib/nodeApi";
import { exportTextAsDocx, exportTextAsPdf } from "../../lib/exportUtils";

const styles = [
  { label: "ACS", value: "acs" },
  { label: "APA", value: "apa" },
  { label: "Chicago", value: "chicago" },
  { label: "Harvard", value: "harvard" },
  { label: "IEEE", value: "ieee" },
  { label: "MLA", value: "mla" },
  { label: "Vancouver", value: "vancouver" },
];

function detectCitationStyle(text) {
  if (/\[[0-9]+(?:,\s*[0-9]+)*\]/.test(text)) return "ieee";
  if (/\([A-Z][A-Za-z-]+,\s*\d{4}\)/.test(text) || /\([A-Z][A-Za-z-]+\s+et al\.,\s*\d{4}\)/i.test(text)) return "apa";
  if (/[A-Z][A-Za-z-]+,\s+[A-Z][A-Za-z-]+\.?\s+".+?"\s+.+?,\s+\d{4}/.test(text)) return "mla";
  if (/\([A-Z][A-Za-z-]+\s+\d{4}\)/.test(text)) return "harvard";
  return "";
}

function styleLabel(value) {
  return styles.find((item) => item.value === value)?.label || "Unknown";
}

function scrollTextareaToMatch(textarea, text, index, queryLength) {
  const computed = window.getComputedStyle(textarea);
  const mirror = document.createElement("div");
  const before = document.createElement("span");
  const marker = document.createElement("span");

  mirror.style.position = "absolute";
  mirror.style.visibility = "hidden";
  mirror.style.whiteSpace = "pre-wrap";
  mirror.style.overflowWrap = "break-word";
  mirror.style.boxSizing = "border-box";
  mirror.style.width = `${textarea.clientWidth}px`;
  mirror.style.padding = computed.padding;
  mirror.style.border = computed.border;
  mirror.style.font = computed.font;
  mirror.style.lineHeight = computed.lineHeight;
  mirror.style.letterSpacing = computed.letterSpacing;

  before.textContent = text.slice(0, index);
  marker.textContent = text.slice(index, index + queryLength) || ".";
  mirror.append(before, marker);
  document.body.appendChild(mirror);

  textarea.scrollTop = Math.max(
    marker.offsetTop - textarea.clientHeight / 2 + marker.offsetHeight,
    0
  );

  mirror.remove();
}

function ExtractedTextPanel({ children, extractedText, originalCitationStyle = "", lastCitationStyle = "", paper, searchQuery, setExtractedText, setOriginalCitationStyle, setLastCitationStyle }) {
  const [mode, setMode] = useState("text");
  const [style, setStyle] = useState("ieee");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [matchStatus, setMatchStatus] = useState("");
  const textareaRef = useRef(null);
  const [saveStatus, setSaveStatus] = useState("");
  const detectedStyle = detectCitationStyle(extractedText);
  const currentCitationStyle = lastCitationStyle || detectedStyle || "";

  useEffect(() => {
    if (!originalCitationStyle && detectedStyle) {
      setOriginalCitationStyle?.(detectedStyle);
      if (paper) {
        trySaveExtractedText(paper, extractedText, {
          originalCitationStyle: detectedStyle,
          citationStyle: detectedStyle,
        });
      }
    }
  }, [detectedStyle, extractedText, originalCitationStyle, paper, setOriginalCitationStyle]);

  useEffect(() => {
    if (lastCitationStyle) {
      setStyle(lastCitationStyle);
    } else if (detectedStyle) {
      setStyle(detectedStyle);
    }
  }, [detectedStyle, lastCitationStyle, paper]);

  useEffect(() => {
    const query = searchQuery.trim();

    if (!query) {
      setMatchStatus("");
      return;
    }

    setMode("text");

    requestAnimationFrame(() => {
      const textarea = textareaRef.current;
      const index = extractedText.toLowerCase().indexOf(query.toLowerCase());

      if (!textarea || index < 0) {
        setMatchStatus(`No match for "${query}"`);
        return;
      }

      textarea.focus();
      textarea.setSelectionRange(index, index + query.length);
      scrollTextareaToMatch(textarea, extractedText, index, query.length);
      const lineNumber = extractedText.slice(0, index).split("\n").length;
      setMatchStatus(`Found "${query}" near line ${lineNumber}`);
    });
  }, [extractedText, searchQuery]);

  async function handleCitationChange() {
    if (!paper) return;

    setLoading(true);
    setError("");

    try {
      const result = await changeCitationStyle(paper, style);
      setExtractedText(result.text);
      setLastCitationStyle?.(style);
      setStyle(style);
      await trySaveExtractedText(paper, result.text, {
        citationStyle: style,
        lastCitationStyle: style,
        ...(originalCitationStyle ? { originalCitationStyle } : {}),
      });
      await tryRecordHistory("citation", `Changed citations to ${style.toUpperCase()}`, paper);
    } catch (err) {
      setError(err.response?.data?.detail || "Could not change citation style");
    } finally {
      setLoading(false);
    }
  }

  async function handleSaveText() {
    if (!paper) return;

    await trySaveExtractedText(paper, extractedText, {
      citationStyle: style,
      lastCitationStyle: style,
      ...(originalCitationStyle ? { originalCitationStyle } : {}),
    });
    setLastCitationStyle?.(style);
    setStyle(style);
    setSaveStatus("Saved");
    setTimeout(() => setSaveStatus(""), 1500);
  }

  return (
    <div className="flex h-full min-h-[34rem] flex-col p-3 sm:p-4">
      <div className="mb-3 flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0">
          <h2 className="text-lg font-semibold text-primary dark:text-softBlue">
            {mode === "text" ? "Extracted Text" : "PDF Preview"}
          </h2>
          <p className="text-sm text-textSecondary">
            {paper || "Upload a PDF to begin"}
          </p>
          {mode === "text" && paper && (
            <p className="mt-1 text-xs text-textSecondary">
              Original citation: {originalCitationStyle ? styleLabel(originalCitationStyle) : "Not detected"}
              {" | "}
              Current citation: {currentCitationStyle ? styleLabel(currentCitationStyle) : "Not detected"}
              {lastCitationStyle ? ` | Last changed: ${styleLabel(lastCitationStyle)}` : ""}
            </p>
          )}
        </div>

        <div className="grid w-full grid-cols-2 gap-2 sm:flex sm:flex-wrap sm:items-center lg:w-auto lg:justify-end">
          {mode === "text" && (
            <>
              <select
                value={style}
                onChange={(event) => setStyle(event.target.value)}
                className="col-span-2 rounded-lg border border-greyBlue bg-white px-3 py-2 text-sm text-textPrimary dark:bg-slate-900 dark:text-gray-100 sm:col-span-1"
              >
                {styles.map((item) => (
                  <option key={item.value} value={item.value}>
                    {item.label}
                  </option>
                ))}
              </select>

              <button
                onClick={handleCitationChange}
                disabled={!paper || loading}
                className="rounded-lg bg-accent px-3 py-2 text-sm text-white disabled:opacity-50 sm:px-4"
              >
                {loading ? "Changing..." : "Change Citation"}
              </button>

              <button
                onClick={handleSaveText}
                disabled={!paper}
                className="rounded-lg bg-primary px-3 py-2 text-sm text-white disabled:opacity-50 sm:px-4"
              >
                Save
              </button>

              <button
                onClick={() => exportTextAsDocx(paper || "extracted-text", extractedText)}
                disabled={!extractedText}
                className="rounded-lg bg-slate-800 px-3 py-2 text-sm text-white disabled:opacity-50 sm:px-4"
              >
                Save DOCX
              </button>

              <button
                onClick={() => exportTextAsPdf(paper || "extracted-text", extractedText)}
                disabled={!extractedText}
                className="rounded-lg bg-slate-800 px-3 py-2 text-sm text-white disabled:opacity-50 sm:px-4"
              >
                Save PDF
              </button>
            </>
          )}

          <button
            onClick={() => setMode(mode === "text" ? "pdf" : "text")}
            disabled={!paper}
            className="rounded-lg bg-primary px-3 py-2 text-sm text-white disabled:opacity-50 sm:px-4"
          >
            {mode === "text" ? "View PDF" : "Edit Text"}
          </button>
        </div>
      </div>

      {error && (
        <p className="mb-3 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
          {error}
        </p>
      )}

      {matchStatus && mode === "text" && (
        <p className="mb-2 rounded-lg border border-yellow-200 bg-yellow-50 px-3 py-2 text-sm text-yellow-900">
          {matchStatus}
        </p>
      )}

      {saveStatus && mode === "text" && (
        <p className="mb-2 rounded-lg border border-green-200 bg-green-50 px-3 py-2 text-sm text-green-800">
          {saveStatus}
        </p>
      )}

      {mode === "text" ? (
        <textarea
          id="extracted-text-search-target"
          ref={textareaRef}
          value={extractedText}
          onChange={(event) => setExtractedText(event.target.value)}
          placeholder="Extracted text will appear here after upload."
          className="min-h-[24rem] flex-1 resize-none overflow-y-auto rounded-lg border border-greyBlue bg-white p-4 font-sans text-sm leading-7 text-textPrimary outline-none selection:bg-yellow-200 selection:text-slate-950 dark:border-slate-700 dark:bg-slate-900 dark:text-gray-100 sm:p-6 sm:text-base"
        />
      ) : (
        <div className="min-h-0 flex-1 overflow-hidden rounded-lg border border-greyBlue bg-white dark:border-slate-700">
          {children}
        </div>
      )}
    </div>
  );
}

export default ExtractedTextPanel;
