def chunk_text(pages, chunk_size=800, overlap=200):

    chunks = []

    for page_num, page in enumerate(pages, start=1):

        if isinstance(page, dict):
            text = page["text"]
            source_page_num = page["page"]
        else:
            text = page
            source_page_num = page_num

        start = 0

        while start < len(text):

            end = start + chunk_size

            chunk = text[start:end]

            chunks.append({
                "text": chunk,
                "page": source_page_num
            })

            start += chunk_size - overlap

    return chunks
