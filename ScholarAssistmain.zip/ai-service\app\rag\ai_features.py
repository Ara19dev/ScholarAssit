from google import genai
from google.genai import types

from app.config import GEMINI_API_KEY, LLM_MODEL
from app.rag.errors import raise_friendly_ai_error

client = genai.Client(api_key=GEMINI_API_KEY)


SUPPORTED_CITATION_STYLES = {
    "acs": "American Chemical Society (ACS)",
    "apa": "APA",
    "chicago": "Chicago",
    "harvard": "Harvard",
    "ieee": "IEEE",
    "mla": "MLA",
    "vancouver": "Vancouver",
}


def _resolve_citation_style(citation_style):
    normalized_style = citation_style.strip().lower()

    if normalized_style in SUPPORTED_CITATION_STYLES:
        return SUPPORTED_CITATION_STYLES[normalized_style]

    for style_name in SUPPORTED_CITATION_STYLES.values():
        normalized_name = style_name.lower()

        if normalized_style == normalized_name or normalized_style in normalized_name:
            return style_name

    supported = ", ".join(SUPPORTED_CITATION_STYLES.values())
    raise ValueError(f"Unsupported citation style. Supported styles: {supported}")


def _extract_grounding_sources(response):
    sources = []

    for candidate in response.candidates or []:
        grounding_metadata = getattr(candidate, "grounding_metadata", None)

        if not grounding_metadata:
            continue

        for chunk in grounding_metadata.grounding_chunks or []:
            web = getattr(chunk, "web", None)

            if web and web.uri:
                sources.append({
                    "title": web.title,
                    "url": web.uri,
                })

    return sources


def generate_internet_plagiarism_report(paper_name, source_text):
    web_search_tool = types.Tool(googleSearch=types.GoogleSearch())

    prompt = f"""
You are an academic plagiarism analysis assistant.

Use Google Search to check whether the uploaded paper text appears to overlap with publicly available internet sources.

Uploaded PDF name:
{paper_name}

Return the report using exactly these plain-text headings.
Use short bullets under each heading.
Do not use markdown tables, pipe characters, HTML, or hash headings.
Overall risk:
Likely internet overlap:
Matched web sources with URLs:
Reasoning:
Suggested rewrite guidance:

Rules:
- Search the web for distinctive phrases, claims, and passages from the supplied text.
- Do not compare against locally uploaded documents.
- Do not invent matches.
- If web search does not find reliable evidence, say that clearly.
- Keep the report practical and concise.

Uploaded paper text:
{source_text}
"""

    try:
        response = client.models.generate_content(
            model=LLM_MODEL,
            contents=prompt,
            config=types.GenerateContentConfig(
                tools=[web_search_tool],
                temperature=0.2,
            )
        )
    except Exception as error:
        raise_friendly_ai_error(error)

    return {
        "report": response.text,
        "sources": _extract_grounding_sources(response),
    }


def change_citation_style(extracted_text, citation_style):
    style_name = _resolve_citation_style(citation_style)

    prompt = f"""
You are an academic citation formatting assistant.

Rewrite the extracted text below so its in-text citations and reference-style citation markers follow {style_name}.

Rules:
- Preserve the original meaning and wording as much as possible.
- Only change citation formatting and citation markers.
- Do not add new bibliographic facts that are not present.
- If a citation lacks enough information for perfect formatting, keep the available details and mark missing fields as [missing].
- Return only the revised extracted text.

Extracted text:
{extracted_text}
"""

    try:
        response = client.models.generate_content(
            model=LLM_MODEL,
            contents=prompt
        )
    except Exception as error:
        raise_friendly_ai_error(error)

    return response.text
