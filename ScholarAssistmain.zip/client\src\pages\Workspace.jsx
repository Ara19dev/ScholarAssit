import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import Sidebar from "../components/layout/Sidebar";
import PaperViewer from "../components/papers/PaperViewer";
import UploadPaper from "../components/papers/UploadPaper";
import ExtractedTextPanel from "../components/papers/ExtractedTextPanel";
import SemanticSearch from "../components/search/SemanticSearch";
import NoteEditor from "../components/notes/NoteEditor";
import SummaryPanel from "../components/ai/SummaryPanel";
import TopNavbar from "../components/layout/TopNavbar";
import FloatingChat from "../components/ai/FloatingChat";
import PlagiarismPanel from "../components/plagiarism/PlagiarismPanel";
import { fetchUserPapers } from "../lib/nodeApi";

function Workspace() {

  const location = useLocation();
  const requestedPaper = location.state?.paper || "";
  const [file, setFile] = useState(null);
  const [paper, setPaper] = useState("");
  const [extractedText, setExtractedText] = useState("");
  const [savedPapers, setSavedPapers] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [lastCitationStyle, setLastCitationStyle] = useState("");
  const [originalCitationStyle, setOriginalCitationStyle] = useState("");

  useEffect(() => {
    async function loadSavedPapers() {
      try {
        const papers = await fetchUserPapers();
        setSavedPapers(papers);

        const requestedSavedPaper = requestedPaper
          ? papers.find((item) => item.filename === requestedPaper)
          : null;
        const nextPaper = requestedSavedPaper || (!paper ? papers[0] : null);

        if (nextPaper) {
          setPaper(nextPaper.filename);
          setExtractedText(nextPaper.extractedText || "");
          setOriginalCitationStyle(nextPaper.originalCitationStyle || "");
          setLastCitationStyle(nextPaper.lastCitationStyle || nextPaper.citationStyle || "");
        }
      } catch {
        setSavedPapers([]);
      }
    }

    loadSavedPapers();
  }, [paper, requestedPaper]);

  function handlePaperIndexed(result, selectedFile) {
    setPaper(result.paper);
    setExtractedText(result.extracted_text || "");
    setOriginalCitationStyle("");
    setLastCitationStyle("");
    setSavedPapers((current) => {
      const nextPaper = {
        filename: result.paper,
        originalName: selectedFile.name,
        chunks: result.chunks,
        extractedText: result.extracted_text || "",
        originalCitationStyle: "",
        citationStyle: "",
        lastCitationStyle: "",
      };

      return [
        nextPaper,
        ...current.filter((item) => item.filename !== result.paper),
      ];
    });
  }

  function handleSelectSavedPaper(savedPaper) {
    setFile(null);
    setPaper(savedPaper.filename);
    setExtractedText(savedPaper.extractedText || "");
    setOriginalCitationStyle(savedPaper.originalCitationStyle || "");
    setLastCitationStyle(savedPaper.lastCitationStyle || savedPaper.citationStyle || "");
    setSearchQuery("");
  }

  function handleSearch(query) {
    const nextQuery = query.trim();

    setSearchQuery(nextQuery);

    if (!nextQuery) return;

    requestAnimationFrame(() => {
      document
        .getElementById("extracted-text-search-target")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  return (

    <div className="scholar-pattern-bg flex min-h-screen flex-col text-gray-900 dark:text-gray-100 lg:h-screen lg:overflow-hidden">

      <TopNavbar />

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">

        <Sidebar
          papers={savedPapers}
          selectedPaper={paper}
          onSelectPaper={handleSelectSavedPaper}
        />

        <div className="scholar-pattern-bg flex min-w-0 flex-1 flex-col xl:flex-row">

          <div className="flex min-w-0 flex-1 flex-col xl:border-r xl:border-gray-200 xl:dark:border-gray-700">

            <div className="border-b border-greyBlue p-3 dark:border-slate-700 sm:p-4">
              <div className="mb-3">
                <h1 className="text-2xl font-bold text-primary dark:text-white">
                  Editor Dashboard
                </h1>
                <p className="text-sm text-textSecondary dark:text-blue-100">
                  Upload, search, edit, and review the selected paper.
                </p>
              </div>

              <div className="flex flex-col gap-3 md:flex-row md:items-start">
                <UploadPaper
                  compact
                  setFile={setFile}
                  setPaper={setPaper}
                  onIndexed={handlePaperIndexed}
                />

                <div className="min-w-0 flex-1 md:ml-auto md:max-w-2xl">
                  <SemanticSearch compact onSearch={handleSearch} />
                </div>
              </div>
            </div>

            <ExtractedTextPanel
              extractedText={extractedText}
              paper={paper}
              searchQuery={searchQuery}
              setExtractedText={setExtractedText}
              originalCitationStyle={originalCitationStyle}
              setOriginalCitationStyle={setOriginalCitationStyle}
              lastCitationStyle={lastCitationStyle}
              setLastCitationStyle={setLastCitationStyle}
            >
              <PaperViewer file={file} paper={paper} />
            </ExtractedTextPanel>

          </div>

          <div className="flex max-h-[44rem] w-full shrink-0 flex-col overflow-y-auto border-t border-greyBlue bg-gray-100 dark:border-slate-700 dark:bg-[#0B1120] xl:h-full xl:max-h-none xl:w-[34rem] xl:border-t-0">

            <SummaryPanel paper={paper} />

            <PlagiarismPanel paper={paper} />

            <NoteEditor paper={paper} />

          </div>

        </div>

      </div>

      <FloatingChat paper={paper} />

    </div>

  );
}

export default Workspace;
