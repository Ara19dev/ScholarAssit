function DashboardCard({ icon, title, value }) {
  return (
    <div className="rounded-xl border border-greyBlue bg-white p-4 shadow-sm dark:border-slate-700 dark:bg-[#0B1120] sm:p-6">
      {icon && (
        <div className="mb-3 inline-flex rounded-lg bg-[#D0E3FF] p-2.5 text-[#334EAC] sm:mb-4 sm:p-3">
          {icon}
        </div>
      )}

      <h3 className="text-sm text-textSecondary dark:text-blue-100">
        {title}
      </h3>

      <p className="mt-2 text-xl font-bold text-primary dark:text-white sm:text-2xl">
        {value}
      </p>

    </div>
  );
}

export default DashboardCard;
