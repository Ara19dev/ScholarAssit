import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ArrowLeft, GitCompare } from "lucide-react";

import StructuredOutput from "../components/common/StructuredOutput";
import Sidebar from "../components/layout/Sidebar";
import TopNavbar from "../components/layout/TopNavbar";
import { comparePapers } from "../lib/api";
import { fetchUserPapers, tryRecordHistory } from "../lib/nodeApi";

function ComparePapers() {
  const navigate = useNavigate();
  const [papers, setPapers] = useState([]);
  const [paperA, setPaperA] = useState("");
  const [paperB, setPaperB] = useState("");
  const [comparison, setComparison] = useState("");
  const [similarity, setSimilarity] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadPapers() {
      const rows = await fetchUserPapers();
      setPapers(rows);
      setPaperA(rows[0]?.filename || "");
      setPaperB(rows[1]?.filename || "");
    }

    loadPapers();
  }, []);

  const paperAOptions = papers.filter((paper) => paper.filename !== paperB);
  const paperBOptions = papers.filter((paper) => paper.filename !== paperA);

  function handlePaperAChange(filename) {
    setPaperA(filename);

    if (filename === paperB) {
      setPaperB(papers.find((paper) => paper.filename !== filename)?.filename || "");
    }
  }

  function handlePaperBChange(filename) {
    setPaperB(filename);

    if (filename === paperA) {
      setPaperA(papers.find((paper) => paper.filename !== filename)?.filename || "");
    }
  }

  async function handleCompare() {
    if (!paperA || !paperB) return;
    setLoading(true);
    setError("");

    try {
      const result = await comparePapers(paperA, paperB);
      setComparison(result.comparison);
      setSimilarity(result.similarity);
      await tryRecordHistory("compare", `Compared ${paperA} with ${paperB}`);
    } catch (err) {
      setError(err.response?.data?.detail || "Could not compare papers");
    } finally {
      setLoading(false);
    }
  }

  const chartData = [
    { name: "Similarity", value: similarity || 0 },
    { name: "Difference", value: similarity === null ? 0 : 100 - similarity },
  ];

  function handleSidebarPaperSelect(paper) {
    navigate("/workspace", { state: { paper: paper.filename } });
  }

  return (
    <div className="scholar-pattern-bg flex min-h-screen flex-col text-textPrimary dark:text-gray-100 lg:h-screen lg:overflow-hidden">
      <TopNavbar />

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <Sidebar
          papers={papers}
          selectedPaper=""
          onSelectPaper={handleSidebarPaperSelect}
        />

      <main className="min-w-0 flex-1 overflow-y-auto px-3 py-5 sm:px-6 sm:py-8">
        <div className="mx-auto max-w-7xl">
        <Link to="/workspace" className="mb-6 inline-flex items-center gap-2 text-accent dark:text-softBlue">
          <ArrowLeft size={16} />
          Back to workspace
        </Link>

        <div className="mb-6 flex items-start gap-3 sm:mb-8 sm:items-center">
          <div className="shrink-0 rounded-lg bg-[#D0E3FF] p-3 text-[#334EAC]">
            <GitCompare size={28} />
          </div>
          <div className="min-w-0">
            <h1 className="text-2xl font-bold text-primary dark:text-white sm:text-4xl">
              Compare Papers
            </h1>
            <p className="text-textSecondary dark:text-blue-100">
              Select two uploaded papers and compare their overlap, methods, and contributions.
            </p>
          </div>
        </div>

        <section className="mb-6 rounded-xl border border-greyBlue bg-white p-3 shadow-sm dark:border-slate-700 dark:bg-[#0B1120] sm:p-6">
          <div className="grid gap-3 sm:gap-4 lg:grid-cols-[1fr_1fr_auto]">
            <select
              value={paperA}
              onChange={(event) => handlePaperAChange(event.target.value)}
              className="min-w-0 rounded-lg border border-greyBlue bg-white p-3 text-textPrimary dark:border-slate-700 dark:bg-slate-900 dark:text-gray-100"
            >
              {paperAOptions.map((paper) => (
                <option key={paper.filename} value={paper.filename}>
                  {paper.originalName || paper.filename}
                </option>
              ))}
            </select>

            <select
              value={paperB}
              onChange={(event) => handlePaperBChange(event.target.value)}
              className="min-w-0 rounded-lg border border-greyBlue bg-white p-3 text-textPrimary dark:border-slate-700 dark:bg-slate-900 dark:text-gray-100"
            >
              {paperBOptions.map((paper) => (
                <option key={paper.filename} value={paper.filename}>
                  {paper.originalName || paper.filename}
                </option>
              ))}
            </select>

            <button
              onClick={handleCompare}
              disabled={!paperA || !paperB || loading}
              className="rounded-lg bg-[#334EAC] px-6 py-3 font-semibold text-white disabled:opacity-50"
            >
              {loading ? "Comparing..." : "Compare"}
            </button>
          </div>

          {error && (
            <p className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3 text-red-700">
              {error}
            </p>
          )}
        </section>

        <div className="grid gap-4 sm:gap-6 lg:grid-cols-[0.8fr_1.2fr]">
          <section className="rounded-xl border border-greyBlue bg-white p-3 shadow-sm dark:border-slate-700 dark:bg-[#0B1120] sm:p-6">
            <h2 className="mb-4 text-xl font-semibold text-primary dark:text-softBlue">
              Similarity Graph
            </h2>

            <div className="mb-5">
              <div className="mb-2 flex items-end justify-between gap-3">
                <span className="text-sm font-semibold text-textSecondary dark:text-gray-100">
                  Lexical overlap
                </span>
                <span className="text-3xl font-bold text-primary dark:text-softBlue">
                  {similarity === null ? "--" : `${similarity}%`}
                </span>
              </div>
              <div className="h-3 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                <div
                  className="h-full rounded-full bg-[#334EAC]"
                  style={{ width: `${similarity || 0}%` }}
                />
              </div>
            </div>

            <div className="h-64 sm:h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" stroke="#A9CBE0" />
                  <YAxis domain={[0, 100]} stroke="#A9CBE0" />
                  <Tooltip formatter={(value) => `${value}%`} />
                  <Bar dataKey="value" fill="#334EAC" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {similarity !== null && (
              <p className="mt-4 text-center text-2xl font-bold text-primary dark:text-softBlue">
                {similarity}% lexical similarity
              </p>
            )}
          </section>

          <section className="rounded-xl border border-greyBlue bg-white p-3 shadow-sm dark:border-slate-700 dark:bg-[#0B1120] sm:p-6">
            <h2 className="mb-4 text-xl font-semibold text-primary dark:text-softBlue">
              Structured Comparison
            </h2>
            <div className="max-h-[34rem] overflow-y-auto rounded-lg border border-greyBlue bg-[#F8FBFC] p-3 leading-7 dark:border-slate-700 dark:bg-slate-900 sm:p-4">
              <StructuredOutput
                text={comparison}
                empty="Select two papers and run comparison."
              />
            </div>
          </section>
        </div>
        </div>
      </main>
      </div>
    </div>
  );
}

export default ComparePapers;
