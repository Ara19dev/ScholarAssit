import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { BookOpen, Lock, Mail, User } from "lucide-react";

import { useAuth } from "../context/useAuth";
import TopNavbar from "../components/layout/TopNavbar";

function AuthPage({ initialMode = "login" }) {
  const navigate = useNavigate();
  const auth = useAuth();
  const [mode, setMode] = useState(initialMode);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const isSignup = mode === "signup";

  async function handleSubmit(event) {
    event.preventDefault();
    setLoading(true);
    setError("");

    try {
      if (isSignup) {
        await auth.signup(name, email, password);
      } else {
        await auth.login(email, password);
      }

      navigate("/workspace");
    } catch (err) {
      setError(
        err.response?.data?.message
        || (err.request ? "Could not reach the account server. Check that the Node API is running and CORS allows this frontend URL." : "Authentication failed")
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="research-hero-bg relative min-h-screen overflow-x-hidden">
      <div className="hero-grid-layer absolute inset-0 opacity-60 dark:opacity-15" />
      <div className="hero-dot-layer absolute inset-0 opacity-45 dark:opacity-30" />
      <div className="hero-diagonal-layer absolute inset-0 opacity-40 dark:opacity-20" />
      <div className="hero-contour-layer absolute inset-0 opacity-[0.08] dark:opacity-[0.09]" />
      <div className="absolute left-[-200px] top-[-200px] h-[600px] w-[600px] bg-[#567CBD] opacity-20 blur-[200px] dark:opacity-30" />
      <div className="absolute bottom-[-200px] right-[-200px] h-[500px] w-[500px] bg-[#7096D1] opacity-20 blur-[200px] dark:opacity-30" />
      <div className="absolute left-1/2 top-1/3 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-[#BAD6EB] opacity-10 blur-[160px]" />

      <TopNavbar transparent />

      <div className="relative z-10 mx-auto flex min-h-[calc(100vh-68px)] max-w-6xl flex-col items-center gap-8 px-4 py-8 sm:px-6 sm:py-10 lg:flex-row">
        <section className="hidden flex-1 pr-0 md:block lg:pr-12">
          <h1 className="max-w-xl text-3xl font-bold leading-tight text-primary dark:text-white lg:text-5xl">
            Keep every paper, note, and AI insight tied to your account.
          </h1>

          <p className="mt-6 max-w-lg text-lg text-textSecondary dark:text-[#BAD6EB]">
            Upload research PDFs, extract text, save notes, revisit history, and continue Q&A from the same workspace.
          </p>

          <div className="mt-8 grid max-w-lg grid-cols-2 gap-3 lg:mt-10 lg:gap-4">
            {["Saved PDFs", "Research Notes", "Activity History", "AI Workspace"].map((item) => (
              <div key={item} className="rounded-lg border border-[#334EAC]/15 bg-white/50 p-4 font-semibold backdrop-blur dark:border-white/10 dark:bg-white/10">
                {item}
              </div>
            ))}
          </div>
        </section>

        <form
          onSubmit={handleSubmit}
          className="w-full max-w-md rounded-xl border border-[#334EAC]/15 bg-white/80 p-4 shadow-2xl backdrop-blur dark:border-white/10 dark:bg-white/10 sm:p-6"
        >
          <div className="mb-6 flex items-center gap-3">
            <div className="rounded-lg bg-[#334EAC] p-3 text-white">
              <BookOpen size={22} />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-primary dark:text-white">
                Research Account
              </h2>
              <p className="text-sm text-textSecondary dark:text-[#BAD6EB]">
                Sign in or create a workspace.
              </p>
            </div>
          </div>

          <div className="mb-6 grid grid-cols-2 rounded-lg bg-[#D0E3FF] p-1 dark:bg-black/20">
            <button
              type="button"
              onClick={() => setMode("login")}
              className={`rounded-md py-2 text-sm font-semibold transition ${!isSignup ? "bg-white text-[#081F5C] shadow-sm" : "text-textSecondary dark:text-[#BAD6EB]"}`}
            >
              Login
            </button>
            <button
              type="button"
              onClick={() => setMode("signup")}
              className={`rounded-md py-2 text-sm font-semibold transition ${isSignup ? "bg-white text-[#081F5C] shadow-sm" : "text-textSecondary dark:text-[#BAD6EB]"}`}
            >
              Signup
            </button>
          </div>

          {isSignup && (
            <label className="mb-4 block">
              <span className="mb-2 block text-sm text-textSecondary dark:text-[#BAD6EB]">Name</span>
              <div className="flex items-center gap-3 rounded-lg border border-[#334EAC]/20 bg-white px-3 dark:border-white/20">
                <User size={18} className="text-[#668CA9]" />
                <input
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  placeholder="Your name"
                  className="w-full py-3 text-textPrimary outline-none"
                />
              </div>
            </label>
          )}

          <label className="mb-4 block">
            <span className="mb-2 block text-sm text-textSecondary dark:text-[#BAD6EB]">Email</span>
            <div className="flex items-center gap-3 rounded-lg border border-[#334EAC]/20 bg-white px-3 dark:border-white/20">
              <Mail size={18} className="text-[#668CA9]" />
              <input
                value={email}
                onChange={(event) => setEmail(event.target.value)}
                placeholder="you@example.com"
                type="email"
                className="w-full py-3 text-textPrimary outline-none"
              />
            </div>
          </label>

          <label className="mb-4 block">
            <span className="mb-2 block text-sm text-textSecondary dark:text-[#BAD6EB]">Password</span>
            <div className="flex items-center gap-3 rounded-lg border border-[#334EAC]/20 bg-white px-3 dark:border-white/20">
              <Lock size={18} className="text-[#668CA9]" />
              <input
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="At least 6 characters"
                type="password"
                className="w-full py-3 text-textPrimary outline-none"
              />
            </div>
          </label>

          {error && (
            <p className="mb-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
              {error}
            </p>
          )}

          <button
            disabled={loading}
            className="w-full rounded-lg bg-[#334EAC] p-3 font-semibold text-white hover:bg-[#567CBD] disabled:opacity-60"
          >
            {loading ? "Please wait..." : isSignup ? "Create Account" : "Login"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default AuthPage;
