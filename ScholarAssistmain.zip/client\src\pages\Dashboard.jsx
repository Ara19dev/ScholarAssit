import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, FileText, History, NotebookPen, Sparkles } from "lucide-react";

import DashboardCard from "../components/dashboard/DashboardCard";
import RecentActivity from "../components/dashboard/RecentActivity";
import Sidebar from "../components/layout/Sidebar";
import TopNavbar from "../components/layout/TopNavbar";
import { fetchHistory, fetchUserPapers } from "../lib/nodeApi";

function Dashboard() {
  const navigate = useNavigate();
  const [papers, setPapers] = useState([]);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadDashboard() {
      try {
        const [paperRows, historyRows] = await Promise.all([
          fetchUserPapers(),
          fetchHistory(),
        ]);
        setPapers(paperRows);
        setHistory(historyRows);
      } catch (err) {
        setError(err.response?.data?.message || "Could not load dashboard data");
      }
    }

    loadDashboard();
  }, []);

  const noteCount = history.filter((item) => item.action === "note").length;
  const aiCount = history.filter((item) => ["summary", "qna", "citation", "plagiarism", "compare"].includes(item.action)).length;

  function handleSidebarPaperSelect(paper) {
    navigate("/workspace", { state: { paper: paper.filename } });
  }

  return (
    <div className="scholar-pattern-bg flex min-h-screen flex-col text-textPrimary dark:text-gray-100 lg:h-screen lg:overflow-hidden">
      <TopNavbar />

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <Sidebar
          papers={papers}
          selectedPaper=""
          onSelectPaper={handleSidebarPaperSelect}
        />

      <main className="min-w-0 flex-1 overflow-y-auto px-3 py-5 sm:px-6 sm:py-8">
        <div className="mx-auto max-w-7xl">
        <div className="mb-6 flex items-center justify-between sm:mb-8">
          <div>
            <Link to="/workspace" className="mb-4 inline-flex items-center gap-2 text-sm text-accent dark:text-softBlue">
              <ArrowLeft size={16} />
              Back to workspace
            </Link>
            <h1 className="text-2xl font-bold text-primary dark:text-white sm:text-4xl">
              Research Dashboard
            </h1>
            <p className="mt-2 text-textSecondary dark:text-blue-100">
              Your saved papers, notes, and research activity in one place.
            </p>
          </div>
        </div>

        {error && (
          <p className="mb-6 rounded-lg border border-red-200 bg-red-50 p-3 text-red-700">
            {error}
          </p>
        )}

        <div className="mb-6 grid gap-3 sm:mb-8 sm:grid-cols-2 sm:gap-5 lg:grid-cols-4">
          <DashboardCard title="Uploaded Papers" value={papers.length} icon={<FileText size={22} />} />
          <DashboardCard title="AI Actions" value={aiCount} icon={<Sparkles size={22} />} />
          <DashboardCard title="Saved Notes" value={noteCount} icon={<NotebookPen size={22} />} />
          <DashboardCard title="Total Activity" value={history.length} icon={<History size={22} />} />
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
          <section className="rounded-xl border border-greyBlue bg-white p-3 shadow-sm dark:border-slate-700 dark:bg-[#0B1120] sm:p-6">
            <h2 className="mb-4 text-xl font-semibold text-primary dark:text-softBlue">
              Saved Papers
            </h2>

            <div className="space-y-3">
              {papers.map((paper) => (
                <div
                  key={paper._id || paper.filename}
                  className="flex flex-col gap-3 rounded-lg border border-greyBlue p-4 dark:border-slate-700 dark:bg-slate-900 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="min-w-0">
                    <p className="truncate font-semibold">
                      {paper.originalName || paper.filename}
                    </p>
                    <p className="text-sm text-textSecondary dark:text-blue-100">
                      {paper.chunks || 0} chunks indexed
                    </p>
                  </div>
                  <Link
                    to="/workspace"
                    className="rounded-lg bg-[#334EAC] px-4 py-2 text-sm text-white"
                  >
                    Open
                  </Link>
                </div>
              ))}

              {papers.length === 0 && (
                <p className="rounded-lg border border-dashed border-greyBlue p-5 text-textSecondary dark:border-slate-700 dark:text-blue-100">
                  Upload a PDF in the workspace to start building your library.
                </p>
              )}
            </div>
          </section>

          <RecentActivity activities={history} />
        </div>
        </div>
      </main>
      </div>
    </div>
  );
}

export default Dashboard;
