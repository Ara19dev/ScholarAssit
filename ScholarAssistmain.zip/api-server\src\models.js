import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
  },
  { timestamps: true }
);

const paperSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    filename: { type: String, required: true },
    originalName: { type: String, required: true },
    chunks: { type: Number, default: 0 },
    extractedText: { type: String, default: "" },
    pdfFileId: { type: mongoose.Schema.Types.ObjectId, default: null },
    pdfContentType: { type: String, default: "application/pdf" },
    pdfSize: { type: Number, default: 0 },
    originalCitationStyle: { type: String, default: "" },
    citationStyle: { type: String, default: "" },
    lastCitationStyle: { type: String, default: "" },
  },
  { timestamps: true }
);

paperSchema.index({ user: 1, filename: 1 }, { unique: true });

const noteSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    paper: { type: String, required: true },
    body: { type: String, default: "" },
  },
  { timestamps: true }
);

noteSchema.index({ user: 1, paper: 1 }, { unique: true });

const historySchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    paper: { type: String, default: "" },
    action: { type: String, required: true },
    detail: { type: String, default: "" },
  },
  { timestamps: true }
);

export const User = mongoose.model("User", userSchema);
export const Paper = mongoose.model("Paper", paperSchema);
export const Note = mongoose.model("Note", noteSchema);
export const History = mongoose.model("History", historySchema);
