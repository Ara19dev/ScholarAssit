import { useState } from "react";

import { checkPlagiarism } from "../../lib/api";
import { tryRecordHistory } from "../../lib/nodeApi";
import StructuredOutput from "../common/StructuredOutput";

function PlagiarismPanel({ paper }) {
  const [report, setReport] = useState("");
  const [sources, setSources] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleCheck() {
    if (!paper) return;

    setLoading(true);
    setError("");

    try {
      const result = await checkPlagiarism(paper);
      setReport(result.report);
      setSources(result.sources || []);
      await tryRecordHistory("plagiarism", `Checked internet overlap for ${paper}`, paper);
    } catch (err) {
      setError(err.response?.data?.detail || "Could not check plagiarism");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="border-b border-greyBlue p-3 sm:p-4">
      <div className="mb-2 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h3 className="text-primary dark:text-softBlue font-semibold">
          Plagiarism Check
        </h3>

        <button
          onClick={handleCheck}
          disabled={!paper || loading}
          className="rounded-lg bg-primary px-3 py-2 text-sm text-white disabled:opacity-50"
        >
          {loading ? "Checking..." : "Check"}
        </button>
      </div>

      {!paper && (
        <p className="text-textSecondary text-sm">
          Upload and index a PDF to check internet overlap.
        </p>
      )}

      {error && (
        <p className="text-red-600 text-sm">
          {error}
        </p>
      )}

      {report && (
        <div className="max-h-64 overflow-y-auto">
          <StructuredOutput text={report} compact />
        </div>
      )}

      {sources.length > 0 && (
        <div className="mt-3 space-y-2">
          <h4 className="text-sm font-semibold text-primary dark:text-softBlue">
            Web Sources
          </h4>
          {sources.map((source) => (
            <a
              key={source.url}
              href={source.url}
              target="_blank"
              rel="noreferrer"
              className="block rounded-lg border border-greyBlue bg-white/70 p-2 text-sm text-accent underline dark:border-slate-700 dark:bg-slate-900 dark:text-softBlue"
            >
              {source.title || source.url}
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

export default PlagiarismPanel;
